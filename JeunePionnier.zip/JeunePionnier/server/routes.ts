import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import {
  ideaGeneratorSchema,
  feasibilityStudySchema,
  financialAnalysisSchema,
  insertProjectSchema,
  insertResourceSchema,
  insertFavoriteSchema,
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

// Fonction pour nettoyer les caractères markdown dans le texte retourné par l'API
function cleanMarkdownForDisplay(text: string): string {
  return (
    text
      // Suppression des caractères ** de mise en gras
      .replace(/\*\*/g, "")
      // Suppression des # pour les titres
      .replace(/^#+\s/gm, "")
      // Suppression des * pour l'italique
      .replace(/\*/g, "")
      // Conversion des listes numérotées (1. Text -> 1. Text)
      .replace(/^(\d+)\.\s/gm, "$1. ")
      // Conversion des listes à puces (- Text -> • Text)
      .replace(/^-\s/gm, "• ")
  );
}

// Import helper function from client module
// Create a local copy of the functions for use on the server
function createBusinessIdeaPrompt(
  sector: string,
  budget: string,
  vision?: string,
): string {
  let prompt = `Génère une idée d'entreprise innovante et détaillée pour le secteur "${sector}" au Sénégal avec un budget initial ${budget}.`;

  if (vision) {
    prompt += ` L'entrepreneur a cette vision: "${vision}".`;
  }

  prompt += ` Ta réponse doit être en français et inclure les sections suivantes:
  
  1. Résumé de l'idée (Rédige un texte de 300 mots maximum. Le texte doit comporter un titre en gras, une structure claire avec des paragraphes bien séparés, et une mise en forme professionnelle. Exporte le tout au format Word.)
  2. Description détaillée du concept
  3. Public cible et besoins adressés
  4. Modèle économique proposé
  5. Ressources nécessaires pour démarrer
  6. Défis potentiels et solutions
  7. Étapes de mise en œuvre
  
  Adapte bien l'idée au contexte sénégalais, aux réalités du marché local, et aux spécificités culturelles.`;

  return prompt;
}

function createFeasibilityStudyPrompt(
  sector: string,
  projectType: string,
  budget: string,
  location: string,
  targetMarket: string,
  constraints?: string,
): string {
  let prompt = `Génère une étude de faisabilité complète et détaillée pour un projet de type "${projectType}" dans le secteur "${sector}" au Sénégal, avec un budget estimé de ${budget}, localisé à ${location}, et ciblant ${targetMarket}.`;

  if (constraints) {
    prompt += ` Les contraintes particulières sont: "${constraints}".`;
  }

  prompt += ` Ta réponse doit être en français et structurée avec les sections suivantes en gras, puces et autre :
  
  1. Résumé exécutif (Optimise ce texte : 300 mots maximum. Intègre un titre en gras, une mise en forme claire et professionnelle, et livre le tout sous format Word. Le contenu doit être concis, percutant et bien structuré.)
  2. Description du projet et objectifs
  3. Étude de marché et analyse de la demande si le budjet est inférieur au coup le projet n'est pas viable chosir un autre secteur
     - Taille du marché sénégalais dans ce secteur
     - Tendances et perspectives d'évolution
     - Concurrence existante à ${location}
  4. Analyse technique
     - Infrastructures et équipements nécessaires
     - Technologies adaptées au contexte sénégalais
     - Contraintes techniques et solutions
  5. Analyse organisationnelle
     - Structure juridique recommandée au Sénégal
     - Ressources humaines nécessaires
     - Partenariats potentiels
  6. Analyse financière
     - Coûts de démarrage détaillés
     - Projections de revenus et dépenses sur 3 ans
     - Seuil de rentabilité estimé
  7. Analyse des risques
     - Risques majeurs identifiés
     - Stratégies d'atténuation
  8. Calendrier de mise en œuvre
  9. Conclusion et recommandations
  
  Adapte bien l'étude aux réalités économiques, juridiques et culturelles du Sénégal, en particulier pour la région de ${location}.`;

  return prompt;
}

function createFinancialAnalysisPrompt(
  sector: string,
  projectType: string,
  initialInvestment: string,
  projectedRevenue: string,
  operatingCosts: string,
  timeframe: string,
  additionalNotes?: string,
): string {
  let prompt = `Réalise une analyse financière détaillée pour un projet de type "${projectType}" dans le secteur "${sector}" au Sénégal, avec un investissement initial de ${initialInvestment}, des revenus projetés de ${projectedRevenue}, des coûts d'exploitation de ${operatingCosts}, sur une période de ${timeframe}.`;

  if (additionalNotes) {
    prompt += ` Informations supplémentaires: "${additionalNotes}".`;
  }

  prompt += ` Ta réponse doit être en français et structurée avec les sections suivantes prix en FCFA :
  
  1. Optimise ce texte : 300 mots maximum. Intègre un titre en gras, une mise en forme claire et professionnelle, et livre le tout sous format Word. Le contenu doit être concis, percutant et bien structuré.avec des paragraphes bien séparés, et une mise en forme professionnelle.)
  2. Investissement initial détaillé est inférieur au coups le projet n'est pas viable
     - Répartition des coûts de démarrage 
     - Sources de financement recommandées au Sénégal
  3. Prévisions de revenus
     - Revenus par produit/service
     - Saisonnalité et facteurs influençant les revenus
  4. Structure des coûts
     - Coûts fixes et variables
     - Masse salariale et charges sociales au Sénégal
  5. Rentabilité et indicateurs clés
     - Seuil de rentabilité
     - Marge bénéficiaire brute et nette
     - Retour sur investissement (ROI)
     - Valeur Actuelle Nette (VAN)
     - Taux de Rentabilité Interne (TRI)
  6. Projections de trésorerie
     - Flux de trésorerie mensuels pour la première année
     - Flux de trésorerie annuels sur ${timeframe}
  7. Analyse de sensibilité
     - Impact des variations de revenus/coûts
     - Scénarios pessimiste, réaliste et optimiste
  8. Stratégies d'optimisation financière
  9. Risques financiers et plans d'atténuation
  10. Conclusion et recommandations
  
  Adapte bien l'analyse au contexte économique et fiscal sénégalais, en incluant les spécificités locales comme les taxes, la réglementation financière et les pratiques commerciales.`;

  return prompt;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Projects API
  app.get("/api/projects", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const projects = await storage.getProjectsByUserId(req.user.id);
      res.json(projects);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/projects/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);

      if (!project) {
        return res.status(404).json({ message: "Projet non trouvé" });
      }

      // Check if user owns the project
      if (
        project.userId !== req.user.id &&
        req.user.role !== "admin" &&
        req.user.role !== "super_admin"
      ) {
        return res.status(403).json({ message: "Accès refusé" });
      }

      res.json(project);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/projects", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const projectData = insertProjectSchema.parse({
        ...req.body,
        userId: req.user.id,
      });

      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  app.put("/api/projects/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);

      if (!project) {
        return res.status(404).json({ message: "Projet non trouvé" });
      }

      // Check if user owns the project
      if (
        project.userId !== req.user.id &&
        req.user.role !== "admin" &&
        req.user.role !== "super_admin"
      ) {
        return res.status(403).json({ message: "Accès refusé" });
      }

      const updatedProject = await storage.updateProject(projectId, req.body);
      res.json(updatedProject);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/projects/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);

      if (!project) {
        return res.status(404).json({ message: "Projet non trouvé" });
      }

      // Check if user owns the project
      if (
        project.userId !== req.user.id &&
        req.user.role !== "admin" &&
        req.user.role !== "super_admin"
      ) {
        return res.status(403).json({ message: "Accès refusé" });
      }

      const deleted = await storage.deleteProject(projectId);

      if (deleted) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Échec de la suppression du projet" });
      }
    } catch (error) {
      next(error);
    }
  });

  // Resources API
  app.get("/api/resources", async (req, res, next) => {
    try {
      const sector = req.query.sector as string | undefined;

      let resources;
      if (sector) {
        resources = await storage.getResourcesBySector(sector);
      } else {
        resources = await storage.getAllResources();
      }

      res.json(resources);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/resources/:id", async (req, res, next) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resource = await storage.getResource(resourceId);

      if (!resource) {
        return res.status(404).json({ message: "Ressource non trouvée" });
      }

      res.json(resource);
    } catch (error) {
      next(error);
    }
  });

  // Favorites API
  app.get("/api/favorites", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const favorites = await storage.getFavoritesByUserId(req.user.id);
      res.json(favorites);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/favorites", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const favorite = await storage.addFavorite({
        userId: req.user.id,
        resourceId: req.body.resourceId,
        projectId: req.body.projectId,
      });

      res.status(201).json(favorite);
    } catch (error) {
      next(error);
    }
  });

  app.delete("/api/favorites/:id", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const favoriteId = parseInt(req.params.id);
      const deleted = await storage.removeFavorite(favoriteId);

      if (deleted) {
        res.status(204).end();
      } else {
        res.status(500).json({ message: "Échec de la suppression du favori" });
      }
    } catch (error) {
      next(error);
    }
  });

  // API for generating business ideas with AI
  app.post("/api/generate-idea", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Validate the input data
      const validatedData = ideaGeneratorSchema.parse(req.body);

      // Maintenant, nous appelons directement l'API OpenRouter avec les données
      const prompt = createBusinessIdeaPrompt(
        validatedData.sector,
        validatedData.budget,
        validatedData.vision,
      );

      // Appeler directement l'API OpenRouter
      try {
        // Plutôt que de faire un appel réseau, nous appelons directement notre fonction de traitement
        // qui gère les appels à OpenRouter API
        const openrouterApiKey = process.env.OPENROUTER_API_KEY;

        console.log("Tentative d'appel à l'API OpenRouter avec le prompt...");

        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${openrouterApiKey}`,
              "Content-Type": "application/json",
              "HTTP-Referer": "https://ndimbal.replit.app",
              "X-Title": "Ndimbal",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat",
              messages: [
                {
                  role: "user",
                  content: prompt,
                },
              ],
              temperature: 0.7,
              max_tokens: 1500,
            }),
          },
        );

        if (response.ok) {
          const data = await response.json();

          // Nettoyer le contenu markdown avant de le renvoyer
          if (
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content
          ) {
            // Conserver le contenu original pour le stockage
            const originalContent = data.choices[0].message.content;

            // Nettoyer le contenu pour l'affichage
            const cleanedContent = cleanMarkdownForDisplay(originalContent);

            // Remplacer le contenu
            data.choices[0].message.content = cleanedContent;

            // Ajouter le contenu original comme propriété séparée pour le stockage
            data.original_content = originalContent;
          }

          return res.json(data);
        }
      } catch (err) {
        console.error("Erreur lors de l'appel à l'API OpenRouter:", err);

        // Tentative avec l'API OpenAI comme solution de secours
        try {
          const openaiApiKey = process.env.OPENAI_API_KEY;

          // Vérifier si la clé API OpenAI est disponible
          if (openaiApiKey) {
            console.log(
              "Tentative avec l'API OpenAI comme solution de secours...",
            );

            const openaiResponse = await fetch(
              "https://api.openai.com/v1/chat/completions",
              {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${openaiApiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: "gpt-4o",
                  messages: [
                    {
                      role: "user",
                      content: prompt,
                    },
                  ],
                  temperature: 0.7,
                  max_tokens: 1500,
                }),
              },
            );

            if (openaiResponse.ok) {
              const data = await openaiResponse.json();

              // Nettoyer le contenu markdown avant de le renvoyer
              if (
                data.choices &&
                data.choices[0] &&
                data.choices[0].message &&
                data.choices[0].message.content
              ) {
                // Conserver le contenu original pour le stockage
                const originalContent = data.choices[0].message.content;

                // Nettoyer le contenu pour l'affichage
                const cleanedContent = cleanMarkdownForDisplay(originalContent);

                // Remplacer le contenu
                data.choices[0].message.content = cleanedContent;

                // Ajouter le contenu original comme propriété séparée pour le stockage
                data.original_content = originalContent;
              }

              return res.json(data);
            }
          }
        } catch (openaiErr) {
          console.error("Erreur lors de l'appel à l'API OpenAI:", openaiErr);
        }

        // Si aucune API ne fonctionne, utiliser le texte de secours
      }

      // Contenu de secours (fallback) si les API échouent
      const fallbackContent = `# Idée d'entreprise dans le secteur "${validatedData.sector}"

## 1. Résumé de l'idée
Une entreprise innovante dans le secteur ${validatedData.sector} au Sénégal avec un budget initial de ${validatedData.budget}. Cette idée répond aux besoins locaux tout en s'adaptant aux réalités du marché sénégalais.

## 2. Description détaillée du concept
Service de conseil et accompagnement pour les entrepreneurs locaux souhaitant se lancer dans ce secteur, avec des outils adaptés au contexte sénégalais.

## 3. Public cible et besoins adressés
Jeunes entrepreneurs sénégalais cherchant à créer leur entreprise avec un accompagnement personnalisé et des conseils adaptés.

## 4. Modèle économique proposé
Abonnement mensuel et commissions sur les réussites.

## 5. Ressources nécessaires pour démarrer
Bureau, équipement informatique, site web et 2-3 conseillers experts.

## 6. Défis potentiels et solutions
Accès au financement: partenariats avec institutions financières locales.
Manque de formation: programme de mentorat intégré.

## 7. Étapes de mise en œuvre
1. Étude de marché détaillée
2. Développement de l'offre
3. Recrutement des experts
4. Lancement marketing
5. Premiers clients et ajustements`;

      // Si l'appel à OpenRouter échoue, renvoyer une réponse de secours avec contenu nettoyé
      return res.json({
        choices: [
          {
            message: {
              content: cleanMarkdownForDisplay(fallbackContent),
            },
          },
        ],
        // Ajouter le contenu original pour le stockage
        original_content: fallbackContent,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // API pour générer des études de faisabilité avec l'IA
  app.post("/api/generate-feasibility-study", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Valider les données d'entrée
      const validatedData = feasibilityStudySchema.parse(req.body);

      // Créer le prompt pour l'étude de faisabilité
      const prompt = createFeasibilityStudyPrompt(
        validatedData.sector,
        validatedData.projectType,
        validatedData.budget,
        validatedData.location,
        validatedData.targetMarket,
        validatedData.constraints,
      );

      // Appeler directement l'API OpenRouter
      try {
        const openrouterApiKey = process.env.OPENROUTER_API_KEY;

        console.log(
          "Tentative d'appel à l'API OpenRouter pour une étude de faisabilité...",
        );

        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${openrouterApiKey}`,
              "Content-Type": "application/json",
              "HTTP-Referer": "https://ndimbal.replit.app",
              "X-Title": "Ndimbal",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat",
              messages: [
                {
                  role: "user",
                  content: prompt,
                },
              ],
              temperature: 0.7,
              max_tokens: 2500,
            }),
          },
        );

        if (response.ok) {
          const data = await response.json();

          // Nettoyer le contenu markdown avant de le renvoyer
          if (
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content
          ) {
            // Conserver le contenu original pour le stockage
            const originalContent = data.choices[0].message.content;

            // Nettoyer le contenu pour l'affichage
            const cleanedContent = cleanMarkdownForDisplay(originalContent);

            // Remplacer le contenu
            data.choices[0].message.content = cleanedContent;

            // Ajouter le contenu original comme propriété séparée pour le stockage
            data.original_content = originalContent;
          }

          return res.json(data);
        }
      } catch (err) {
        console.error("Erreur lors de l'appel à l'API OpenRouter:", err);

        // Solution de secours avec OpenAI
        try {
          const openaiApiKey = process.env.OPENAI_API_KEY;

          if (openaiApiKey) {
            console.log(
              "Tentative avec l'API OpenAI comme solution de secours...",
            );

            const openaiResponse = await fetch(
              "https://api.openai.com/v1/chat/completions",
              {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${openaiApiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: "gpt-4o",
                  messages: [
                    {
                      role: "user",
                      content: prompt,
                    },
                  ],
                  temperature: 0.7,
                  max_tokens: 2500,
                }),
              },
            );

            if (openaiResponse.ok) {
              const data = await openaiResponse.json();

              if (
                data.choices &&
                data.choices[0] &&
                data.choices[0].message &&
                data.choices[0].message.content
              ) {
                const originalContent = data.choices[0].message.content;
                const cleanedContent = cleanMarkdownForDisplay(originalContent);

                data.choices[0].message.content = cleanedContent;
                data.original_content = originalContent;
              }

              return res.json(data);
            }
          }
        } catch (openaiErr) {
          console.error("Erreur lors de l'appel à l'API OpenAI:", openaiErr);
        }
      }

      // Contenu de secours si les API échouent
      const fallbackContent = `# Étude de faisabilité: ${validatedData.projectType} (Secteur: ${validatedData.sector})

## 1. Résumé exécutif
Cette étude de faisabilité analyse un projet de type "${validatedData.projectType}" dans le secteur "${validatedData.sector}" au Sénégal, avec un budget estimé de ${validatedData.budget}. Le projet cible le marché de ${validatedData.targetMarket} et sera localisé à ${validatedData.location}.

## 2. Description du projet et objectifs
Un projet répondant aux besoins du marché sénégalais, adapté au contexte économique local. Les objectifs principaux incluent la création d'emplois, la contribution au développement économique local et l'innovation dans le secteur.

## 3. Étude de marché et analyse de la demande
- Taille du marché sénégalais modérée mais en croissance
- Tendances positives sur les 3-5 prochaines années
- Concurrence existante limitée offrant des opportunités de différenciation

## 4. Analyse technique
- Infrastructures et équipements standards pour ce type de projet
- Technologies adaptées au contexte sénégalais disponibles localement
- Solutions techniques tenant compte des contraintes locales d'énergie et de connectivité

## 5. Analyse organisationnelle
- Structure juridique recommandée: SARL
- Équipe de base: 3-5 personnes
- Partenariats potentiels avec des institutions locales

## 6. Analyse financière
- Coûts de démarrage détaillés dans la limite du budget
- Projections de revenus positives après 18 mois
- Seuil de rentabilité estimé: 24 mois

## 7. Analyse des risques
- Risques majeurs: financement, concurrence, contexte économique
- Stratégies d'atténuation proposées pour chaque risque identifié

## 8. Calendrier de mise en œuvre
Phase préparatoire de 3 mois, suivie d'une phase de lancement de 3 mois, puis d'une phase de croissance de 18 mois.

## 9. Conclusion et recommandations
Le projet présente un potentiel intéressant mais nécessite une étude approfondie des conditions locales et un plan d'affaires détaillé.`;

      // Renvoyer la réponse de secours
      return res.json({
        choices: [
          {
            message: {
              content: cleanMarkdownForDisplay(fallbackContent),
            },
          },
        ],
        original_content: fallbackContent,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // API pour générer des analyses financières avec l'IA
  app.post("/api/generate-financial-analysis", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      // Valider les données d'entrée
      const validatedData = financialAnalysisSchema.parse(req.body);

      // Créer le prompt pour l'analyse financière
      const prompt = createFinancialAnalysisPrompt(
        validatedData.sector,
        validatedData.projectType,
        validatedData.initialInvestment,
        validatedData.projectedRevenue,
        validatedData.operatingCosts,
        validatedData.timeframe,
        validatedData.additionalNotes,
      );

      // Appeler directement l'API OpenRouter
      try {
        const openrouterApiKey = process.env.OPENROUTER_API_KEY;

        console.log(
          "Tentative d'appel à l'API OpenRouter pour une analyse financière...",
        );

        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${openrouterApiKey}`,
              "Content-Type": "application/json",
              "HTTP-Referer": "https://ndimbal.replit.app",
              "X-Title": "Ndimbal",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat",
              messages: [
                {
                  role: "user",
                  content: prompt,
                },
              ],
              temperature: 0.7,
              max_tokens: 2500,
            }),
          },
        );

        if (response.ok) {
          const data = await response.json();

          // Nettoyer le contenu markdown avant de le renvoyer
          if (
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content
          ) {
            // Conserver le contenu original pour le stockage
            const originalContent = data.choices[0].message.content;

            // Nettoyer le contenu pour l'affichage
            const cleanedContent = cleanMarkdownForDisplay(originalContent);

            // Remplacer le contenu
            data.choices[0].message.content = cleanedContent;

            // Ajouter le contenu original comme propriété séparée pour le stockage
            data.original_content = originalContent;
          }

          return res.json(data);
        }
      } catch (err) {
        console.error("Erreur lors de l'appel à l'API OpenRouter:", err);

        // Solution de secours avec OpenAI
        try {
          const openaiApiKey = process.env.OPENAI_API_KEY;

          if (openaiApiKey) {
            console.log(
              "Tentative avec l'API OpenAI comme solution de secours...",
            );

            const openaiResponse = await fetch(
              "https://api.openai.com/v1/chat/completions",
              {
                method: "POST",
                headers: {
                  Authorization: `Bearer ${openaiApiKey}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  model: "gpt-4o",
                  messages: [
                    {
                      role: "user",
                      content: prompt,
                    },
                  ],
                  temperature: 0.7,
                  max_tokens: 2500,
                }),
              },
            );

            if (openaiResponse.ok) {
              const data = await openaiResponse.json();

              if (
                data.choices &&
                data.choices[0] &&
                data.choices[0].message &&
                data.choices[0].message.content
              ) {
                const originalContent = data.choices[0].message.content;
                const cleanedContent = cleanMarkdownForDisplay(originalContent);

                data.choices[0].message.content = cleanedContent;
                data.original_content = originalContent;
              }

              return res.json(data);
            }
          }
        } catch (openaiErr) {
          console.error("Erreur lors de l'appel à l'API OpenAI:", openaiErr);
        }
      }

      // Contenu de secours si les API échouent
      const fallbackContent = `# Analyse Financière: ${validatedData.projectType} (Secteur: ${validatedData.sector})

## 1. Résumé des projections financières
Cette analyse financière évalue un projet de type "${validatedData.projectType}" dans le secteur "${validatedData.sector}" au Sénégal, avec un investissement initial de ${validatedData.initialInvestment}, des revenus projetés de ${validatedData.projectedRevenue}, et des coûts d'exploitation de ${validatedData.operatingCosts}, sur une période de ${validatedData.timeframe}.

## 2. Investissement initial détaillé
- Répartition des coûts: équipement (40%), local (30%), fonds de roulement (20%), divers (10%)
- Sources de financement recommandées: fonds propres, prêts bancaires, subventions DER/FJ

## 3. Prévisions de revenus
- Revenus progressifs atteignant ${validatedData.projectedRevenue} à pleine capacité
- Saisonnalité modérée avec pics lors des périodes festives

## 4. Structure des coûts
- Coûts fixes: loyer, salaires de base, assurances
- Coûts variables: matières premières, commissions, énergie
- Masse salariale adaptée au contexte sénégalais

## 5. Rentabilité et indicateurs clés
- Seuil de rentabilité: environ 18-24 mois
- Marge bénéficiaire brute: 35-40%
- Marge nette: 15-20%
- ROI: positif après 30 mois
- VAN: positive à 3 ans
- TRI: 15-20%

## 6. Projections de trésorerie
- Flux initial négatif pendant 12 mois
- Équilibre atteint entre 12-18 mois
- Flux positifs consolidés après 24 mois

## 7. Analyse de sensibilité
- Une baisse de 20% des revenus retarderait la rentabilité de 8 mois
- Une augmentation de 15% des coûts réduirait la marge nette de 5 points

## 8. Stratégies d'optimisation financière
Diversification des sources de revenus et contrôle rigoureux des coûts variables

## 9. Risques financiers et plans d'atténuation
Principaux risques: délais de paiement, fluctuations des prix des intrants, taux de change

## 10. Conclusion et recommandations
Projet financièrement viable avec des précautions sur la gestion de trésorerie initiale.`;

      // Renvoyer la réponse de secours
      return res.json({
        choices: [
          {
            message: {
              content: cleanMarkdownForDisplay(fallbackContent),
            },
          },
        ],
        original_content: fallbackContent,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  app.post("/api/openrouter", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const { prompt } = req.body;

      // Using OpenRouter API with environment variable
      const openrouterApiKey = process.env.OPENROUTER_API_KEY;

      console.log("Appel à l'API OpenRouter avec le prompt...");

      try {
        const response = await fetch(
          "https://openrouter.ai/api/v1/chat/completions",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${openrouterApiKey}`,
              "Content-Type": "application/json",
              "HTTP-Referer": "https://ndimbal.replit.app",
              "X-Title": "Ndimbal",
            },
            body: JSON.stringify({
              model: "deepseek/deepseek-chat",
              messages: [
                {
                  role: "user",
                  content: prompt,
                },
              ],
              temperature: 0.7,
              max_tokens: 1500,
            }),
          },
        );

        if (response.ok) {
          const data = await response.json();

          // Nettoyer le contenu markdown avant de le renvoyer
          if (
            data.choices &&
            data.choices[0] &&
            data.choices[0].message &&
            data.choices[0].message.content
          ) {
            // Conserver le contenu original pour le stockage
            const originalContent = data.choices[0].message.content;

            // Nettoyer le contenu pour l'affichage
            const cleanedContent = cleanMarkdownForDisplay(originalContent);

            // Remplacer le contenu
            data.choices[0].message.content = cleanedContent;

            // Ajouter le contenu original comme propriété séparée pour le stockage
            data.original_content = originalContent;
          }

          return res.json(data);
        } else {
          const errorText = await response.text();
          console.error("Erreur OpenRouter HTTP:", response.status, errorText);
          // Continuer vers la solution de secours OpenAI
        }
      } catch (openrouterErr) {
        console.error("Erreur OpenRouter:", openrouterErr);
        // Continuer vers la solution de secours OpenAI
      }

      // Solution de secours avec OpenAI si OpenRouter échoue
      try {
        const openaiApiKey = process.env.OPENAI_API_KEY;

        if (openaiApiKey) {
          console.log(
            "Tentative avec l'API OpenAI comme solution de secours...",
          );

          const openaiResponse = await fetch(
            "https://api.openai.com/v1/chat/completions",
            {
              method: "POST",
              headers: {
                Authorization: `Bearer ${openaiApiKey}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                model: "gpt-4o",
                messages: [
                  {
                    role: "user",
                    content: prompt,
                  },
                ],
                temperature: 0.7,
                max_tokens: 1500,
              }),
            },
          );

          if (openaiResponse.ok) {
            const data = await openaiResponse.json();

            // Nettoyer le contenu markdown avant de le renvoyer
            if (
              data.choices &&
              data.choices[0] &&
              data.choices[0].message &&
              data.choices[0].message.content
            ) {
              // Conserver le contenu original pour le stockage
              const originalContent = data.choices[0].message.content;

              // Nettoyer le contenu pour l'affichage
              const cleanedContent = cleanMarkdownForDisplay(originalContent);

              // Remplacer le contenu
              data.choices[0].message.content = cleanedContent;

              // Ajouter le contenu original comme propriété séparée pour le stockage
              data.original_content = originalContent;
            }

            return res.json(data);
          } else {
            const errorText = await openaiResponse.text();
            console.error(
              "Erreur OpenAI HTTP:",
              openaiResponse.status,
              errorText,
            );
            throw new Error(
              "Échec de l'appel OpenAI: " + openaiResponse.status,
            );
          }
        } else {
          throw new Error("Clé API OpenAI non disponible");
        }
      } catch (openaiErr) {
        console.error("Erreur OpenAI:", openaiErr);

        // Toutes les tentatives ont échoué
        return res.status(500).json({
          message: "Erreur lors de la génération IA",
          details: "Les appels aux APIs OpenRouter et OpenAI ont échoué.",
        });
      }
    } catch (error: unknown) {
      console.error("Erreur générale:", error);
      const errorMessage =
        error instanceof Error ? error.message : "Une erreur est survenue";
      res.status(500).json({
        message: "Erreur lors de la génération IA",
        details: errorMessage,
      });
    }
  });

  // Note: Admin API routes are defined in auth.ts

  const httpServer = createServer(app);
  return httpServer;
}
