import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser, userRoles } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSecret = process.env.SESSION_SECRET || "ndimbal-secret-key-replace-in-production";
  
  const sessionSettings: session.SessionOptions = {
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      httpOnly: true,
      secure: process.env.NODE_ENV === "production"
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        }
        
        // If user is not approved and not an admin, reject login
        if (!user.approved && user.role === userRoles.USER) {
          return done(null, false, { message: "Votre compte est en attente d'approbation" });
        }
        
        return done(null, user);
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { username, email, password, fullName } = req.body;
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ message: "Ce nom d'utilisateur existe déjà" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Cet email est déjà utilisé" });
      }
      
      // Create the first user as super_admin (automatically approved)
      const users = await storage.getAllUsers();
      const isFirstUser = users.length === 0;
      
      const user = await storage.createUser({
        username,
        email,
        fullName,
        password: await hashPassword(password),
        role: isFirstUser ? userRoles.SUPER_ADMIN : userRoles.USER,
        approved: isFirstUser // First user is automatically approved
      });

      // Automatically login after registration if it's the first user (super_admin)
      if (isFirstUser) {
        req.login(user, (err) => {
          if (err) return next(err);
          return res.status(201).json(user);
        });
      } else {
        // For regular users, return success but don't login
        // They need admin approval first
        return res.status(201).json({ 
          message: "Inscription réussie. Votre compte est en attente d'approbation par un administrateur." 
        });
      }
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ 
          message: info?.message || "Nom d'utilisateur ou mot de passe incorrect" 
        });
      }
      
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
  
  // Admin route to get users awaiting approval
  app.get("/api/admin/users/pending", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.user.role !== userRoles.ADMIN && req.user.role !== userRoles.SUPER_ADMIN) {
      return res.sendStatus(403);
    }
    
    try {
      const pendingUsers = await storage.getUsersAwaitingApproval();
      res.json(pendingUsers);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin route to approve user
  app.post("/api/admin/users/:id/approve", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.user.role !== userRoles.ADMIN && req.user.role !== userRoles.SUPER_ADMIN) {
      return res.sendStatus(403);
    }
    
    try {
      const userId = parseInt(req.params.id);
      const updatedUser = await storage.updateUser(userId, { approved: true });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin route to change user role
  app.post("/api/admin/users/:id/role", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.user.role !== userRoles.SUPER_ADMIN) {
      return res.sendStatus(403);
    }
    
    try {
      const userId = parseInt(req.params.id);
      const { role } = req.body;
      
      // Validate role
      if (![userRoles.USER, userRoles.ADMIN].includes(role)) {
        return res.status(400).json({ message: "Rôle invalide" });
      }
      
      const updatedUser = await storage.updateUser(userId, { role });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      res.json(updatedUser);
    } catch (error) {
      next(error);
    }
  });
  
  // Admin route to get all users
  app.get("/api/admin/users", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    if (req.user.role !== userRoles.ADMIN && req.user.role !== userRoles.SUPER_ADMIN) {
      return res.sendStatus(403);
    }
    
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      next(error);
    }
  });
}
