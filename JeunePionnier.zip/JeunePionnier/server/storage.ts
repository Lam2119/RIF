import { users, projects, resources, favorites, type User, type InsertUser, type Project, type InsertProject, type Resource, type InsertResource, type Favorite, type InsertFavorite } from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool, db } from "./db";
import { eq, and, desc, asc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getUsersByRole(role: string): Promise<User[]>;
  getUsersAwaitingApproval(): Promise<User[]>;
  
  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  
  // Resource operations
  getResource(id: number): Promise<Resource | undefined>;
  getAllResources(): Promise<Resource[]>;
  getResourcesBySector(sector: string): Promise<Resource[]>;
  createResource(resource: InsertResource): Promise<Resource>;
  updateResource(id: number, updates: Partial<Resource>): Promise<Resource | undefined>;
  deleteResource(id: number): Promise<boolean>;
  
  // Favorite operations
  getFavoritesByUserId(userId: number): Promise<Favorite[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: any; // session.Store
}

// Configuration de la session store avec PostgreSQL
const PostgresStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any; // session.Store
  
  constructor() {
    this.sessionStore = new PostgresStore({
      pool,
      createTableIfMissing: true
    });
    
    // Initialiser les ressources si aucune n'existe
    this.initializeResourcesIfEmpty();
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // La recherche SQL est sensible à la casse par défaut
    // Pour une recherche insensible à la casse, on peut comparer les deux noms d'utilisateur après transformation
    const allUsers = await db.select().from(users);
    const user = allUsers.find(user => 
      user.username.toLowerCase() === username.toLowerCase()
    );
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    // Recherche insensible à la casse pour l'email également
    const allUsers = await db.select().from(users);
    const user = allUsers.find(user => 
      user.email.toLowerCase() === email.toLowerCase()
    );
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // S'assurer que c'est le premier utilisateur inscrit qui devient super admin
    const allUsers = await this.getAllUsers();
    let role = "user";
    let approved = false;
    
    if (allUsers.length === 0) {
      // Premier utilisateur est super admin et approuvé
      role = "superadmin";
      approved = true;
    }
    
    const [user] = await db.insert(users)
      .values({
        ...insertUser,
        role,
        approved
      })
      .returning();
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(asc(users.fullName));
  }
  
  async getUsersByRole(role: string): Promise<User[]> {
    return await db.select()
      .from(users)
      .where(eq(users.role, role))
      .orderBy(asc(users.fullName));
  }
  
  async getUsersAwaitingApproval(): Promise<User[]> {
    return await db.select()
      .from(users)
      .where(eq(users.approved, false))
      .orderBy(desc(users.createdAt));
  }
  
  // Project operations
  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }
  
  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return await db.select()
      .from(projects)
      .where(eq(projects.userId, userId))
      .orderBy(desc(projects.createdAt));
  }
  
  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects)
      .values({
        ...project,
        progress: 0
      })
      .returning();
    return newProject;
  }
  
  async updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined> {
    const [updatedProject] = await db.update(projects)
      .set(updates)
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }
  
  async deleteProject(id: number): Promise<boolean> {
    const [deleted] = await db.delete(projects)
      .where(eq(projects.id, id))
      .returning({ id: projects.id });
    return !!deleted;
  }
  
  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db.select().from(resources).where(eq(resources.id, id));
    return resource;
  }
  
  async getAllResources(): Promise<Resource[]> {
    return await db.select().from(resources).orderBy(asc(resources.title));
  }
  
  async getResourcesBySector(sector: string): Promise<Resource[]> {
    return await db.select()
      .from(resources)
      .where(eq(resources.sector, sector))
      .orderBy(asc(resources.title));
  }
  
  async createResource(resource: InsertResource): Promise<Resource> {
    const [newResource] = await db.insert(resources).values(resource).returning();
    return newResource;
  }
  
  async updateResource(id: number, updates: Partial<Resource>): Promise<Resource | undefined> {
    const [updatedResource] = await db.update(resources)
      .set(updates)
      .where(eq(resources.id, id))
      .returning();
    return updatedResource;
  }
  
  async deleteResource(id: number): Promise<boolean> {
    const [deleted] = await db.delete(resources)
      .where(eq(resources.id, id))
      .returning({ id: resources.id });
    return !!deleted;
  }
  
  // Favorite operations
  async getFavoritesByUserId(userId: number): Promise<Favorite[]> {
    return await db.select()
      .from(favorites)
      .where(eq(favorites.userId, userId))
      .orderBy(desc(favorites.createdAt));
  }
  
  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [newFavorite] = await db.insert(favorites).values(favorite).returning();
    return newFavorite;
  }
  
  async removeFavorite(id: number): Promise<boolean> {
    const [deleted] = await db.delete(favorites)
      .where(eq(favorites.id, id))
      .returning({ id: favorites.id });
    return !!deleted;
  }
  
  // Initialise les ressources si la table est vide
  private async initializeResourcesIfEmpty() {
    try {
      const existingResources = await db.select().from(resources).limit(1);
      
      if (existingResources.length === 0) {
        console.log("Initialisation des ressources de démonstration...");
        
        const demoResources: InsertResource[] = [
          {
            title: "Guide des démarches administratives au Sénégal",
            description: "Documentation complète sur les procédures de création d'entreprise",
            sector: "Administration",
            type: "document",
            url: "/resources/guide-administratif",
            content: "1. Documents requis:\n- Pièce d'identité\n- Casier judiciaire\n- Attestation de domiciliation\n2. Étapes de création:\n- Inscription au NINEA\n- Registre de commerce\n- Immatriculation fiscale\n3. Coûts associés et délais"
          },
          {
            title: "Opportunités de financement pour entrepreneurs",
            description: "Guide complet des sources de financement disponibles",
            sector: "Finance",
            type: "guide",
            url: "/resources/financement-pme",
            content: "1. DER/FJ: Fonds jusqu'à 50M FCFA\n2. FONGIP: Garanties de crédit\n3. BNDE: Prêts aux PME\n4. Banques commerciales\n5. Microfinance\n6. Business Angels\n7. Programmes d'accompagnement"
          },
          {
            title: "Stratégies de marketing digital",
            description: "Formation en marketing numérique adapté au contexte sénégalais",
            sector: "Marketing",
            type: "video",
            url: "https://www.youtube.com/watch?v=example",
            content: "1. Présence sur les réseaux sociaux\n2. Marketing mobile\n3. SEO local\n4. Publicité en ligne\n5. E-commerce au Sénégal"
          },
          {
            title: "Réseau entrepreneurial sénégalais",
            description: "Annuaire des communautés d'entrepreneurs",
            sector: "Networking",
            type: "link",
            url: "https://entrepreneuriat.sn",
            content: "Principales associations:\n1. CDES\n2. UNACOIS\n3. CNP\n4. OPTIC\n5. Groupements sectoriels"
          },
          {
            title: "Guide juridique pour entreprises",
            description: "Aspects légaux de l'entrepreneuriat",
            sector: "Juridique",
            type: "document",
            url: "/resources/guide-juridique",
            content: "1. Formes juridiques (SA, SARL, GIE)\n2. Droit du travail\n3. Fiscalité\n4. Propriété intellectuelle\n5. Contrats commerciaux"
          },
          {
            title: "Technologies agricoles innovantes",
            description: "Solutions technologiques pour l'agriculture",
            sector: "Agriculture",
            type: "guide",
            url: "/resources/agritech",
            content: "1. Irrigation intelligente\n2. Agriculture de précision\n3. Stockage et conservation\n4. Transformation agro-alimentaire\n5. Certification bio"
          },
          {
            title: "Formation en gestion d'entreprise",
            description: "Cours en ligne pour entrepreneurs",
            sector: "Formation",
            type: "video",
            url: "https://learn.entrepreneuriat.sn",
            content: "Modules:\n1. Business planning\n2. Gestion financière\n3. Marketing\n4. RH\n5. Innovation"
          },
          {
            title: "Opportunités dans l'économie verte",
            description: "Guide des secteurs écologiques porteurs",
            sector: "Environnement",
            type: "document",
            url: "/resources/economie-verte",
            content: "Secteurs:\n1. Énergies renouvelables\n2. Recyclage\n3. Agriculture bio\n4. Éco-construction\n5. Services environnementaux"
          }
        ];
        
        for (const resource of demoResources) {
          await this.createResource(resource);
        }
      }
    } catch (error) {
      console.error("Erreur lors de l'initialisation des ressources:", error);
    }
  }
}

// Remplacer le stockage en mémoire par le stockage en base de données
export const storage = new DatabaseStorage();
