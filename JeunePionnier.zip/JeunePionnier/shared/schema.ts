import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoles = {
  USER: "user",
  ADMIN: "admin",
  SUPER_ADMIN: "super_admin",
} as const;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default(userRoles.USER),
  approved: boolean("approved").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  sector: text("sector").notNull(),
  budget: text("budget"),
  progress: integer("progress").default(0),
  type: text("type").notNull(), // 'idea', 'business_plan', 'market_research'
  content: text("content").notNull(), // JSON stringified content
  createdAt: timestamp("created_at").defaultNow(),
});

export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  sector: text("sector"),
  type: text("type").notNull(), // 'document', 'guide', 'video', 'link'
  url: text("url"),
  content: text("content"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  resourceId: integer("resource_id"),
  projectId: integer("project_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  approved: true,
  role: true,
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
  createdAt: true,
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true,
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

// Extended schemas for validation
export const loginSchema = z.object({
  username: z.string().min(3, "Le nom d'utilisateur doit contenir au moins 3 caractères"),
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
});

export const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, "Le mot de passe doit contenir au moins 6 caractères"),
  email: z.string().email("Email invalide"),
  fullName: z.string().min(3, "Le nom complet doit contenir au moins 3 caractères"),
});

export const ideaGeneratorSchema = z.object({
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  budget: z.string().min(1, "Veuillez sélectionner un budget"),
  vision: z.string().optional(),
});

export const feasibilityStudySchema = z.object({
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  projectType: z.string().min(1, "Veuillez décrire le type de projet"),
  budget: z.string().min(1, "Veuillez indiquer le budget estimé"),
  location: z.string().min(1, "Veuillez indiquer la localisation"),
  targetMarket: z.string().min(1, "Veuillez décrire le marché cible"),
  constraints: z.string().optional(),
});

export const financialAnalysisSchema = z.object({
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  projectType: z.string().min(1, "Veuillez décrire le type de projet"),
  initialInvestment: z.string().min(1, "Veuillez indiquer l'investissement initial"),
  projectedRevenue: z.string().min(1, "Veuillez indiquer les revenus projetés"),
  operatingCosts: z.string().min(1, "Veuillez indiquer les coûts d'exploitation"),
  timeframe: z.string().min(1, "Veuillez indiquer l'horizon temporel"),
  additionalNotes: z.string().optional(),
});

// Types for TypeScript
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;
export type IdeaGeneratorInput = z.infer<typeof ideaGeneratorSchema>;
export type FeasibilityStudyInput = z.infer<typeof feasibilityStudySchema>;
export type FinancialAnalysisInput = z.infer<typeof financialAnalysisSchema>;
