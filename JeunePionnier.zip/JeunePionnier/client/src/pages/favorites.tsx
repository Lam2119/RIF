import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ResourceCard } from '@/components/resource-card';
import { ProjectCard } from '@/components/project-card';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Favorite, Project, Resource } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { AlertCircle, Loader2 } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function Favorites() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [favoriteToRemove, setFavoriteToRemove] = useState<Favorite | null>(null);
  const [activeTab, setActiveTab] = useState<string>("resources");

  // Fetch user's favorites
  const { data: favorites = [], isLoading: isLoadingFavorites, refetch } = useQuery<Favorite[]>({
    queryKey: ['/api/favorites'],
    refetchOnWindowFocus: false,
  });

  // Fetch resources
  const { data: resources = [], isLoading: isLoadingResources } = useQuery<Resource[]>({
    queryKey: ['/api/resources'],
    refetchOnWindowFocus: false,
  });

  // Fetch projects
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    refetchOnWindowFocus: false,
  });

  // Remove favorite mutation
  const removeFavoriteMutation = useMutation({
    mutationFn: async (favoriteId: number) => {
      await apiRequest('DELETE', `/api/favorites/${favoriteId}`);
    },
    onSuccess: () => {
      refetch();
      toast({
        title: "Favori supprimé",
        description: "Le favori a été supprimé avec succès."
      });
      setFavoriteToRemove(null);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la suppression : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Get favorite resources
  const favoriteResourceIds = favorites
    .filter(fav => fav.resourceId)
    .map(fav => fav.resourceId);
  
  const favoriteResources = resources.filter(resource => 
    favoriteResourceIds.includes(resource.id)
  );

  // Get favorite projects
  const favoriteProjectIds = favorites
    .filter(fav => fav.projectId)
    .map(fav => fav.projectId);
  
  const favoriteProjects = projects.filter(project => 
    favoriteProjectIds.includes(project.id)
  );

  // Find favorite by resource or project ID
  const findFavorite = (resourceId: number | null = null, projectId: number | null = null): Favorite | undefined => {
    return favorites.find(fav => 
      (resourceId && fav.resourceId === resourceId) || 
      (projectId && fav.projectId === projectId)
    );
  };

  // Filter resources by search query
  const filteredResources = favoriteResources.filter(resource => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      resource.title.toLowerCase().includes(query) ||
      resource.description.toLowerCase().includes(query) ||
      (resource.sector && resource.sector.toLowerCase().includes(query))
    );
  });

  // Filter projects by search query
  const filteredProjects = favoriteProjects.filter(project => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      project.title.toLowerCase().includes(query) ||
      project.description.toLowerCase().includes(query) ||
      project.sector.toLowerCase().includes(query)
    );
  });

  // Resource action handlers
  const handleResourceClick = (resource: Resource) => {
    if (resource.url) {
      window.open(resource.url, '_blank');
    } else {
      navigate(`/resources/${resource.id}`);
    }
  };

  // Project action handlers
  const handleViewProject = (project: Project) => {
    const baseRoute = project.type === 'idea' ? '/idea-generator' :
                      project.type === 'business_plan' ? '/business-plan' :
                      project.type === 'market_research' ? '/market-research' : '/projects';
                      
    navigate(`${baseRoute}/${project.id}`);
  };

  const handleEditProject = (project: Project) => {
    const baseRoute = project.type === 'idea' ? '/idea-generator' :
                      project.type === 'business_plan' ? '/business-plan' :
                      project.type === 'market_research' ? '/market-research' : '/projects';
                      
    navigate(`${baseRoute}/${project.id}/edit`);
  };

  const handleDownloadProject = (project: Project) => {
    // Download functionality would be implemented here
    toast({
      title: "Téléchargement",
      description: "La fonctionnalité de téléchargement sera bientôt disponible."
    });
  };

  // Remove favorite handlers
  const confirmRemoveResource = (resource: Resource) => {
    const favorite = findFavorite(resource.id);
    if (favorite) {
      setFavoriteToRemove(favorite);
    }
  };

  const confirmRemoveProject = (project: Project) => {
    const favorite = findFavorite(null, project.id);
    if (favorite) {
      setFavoriteToRemove(favorite);
    }
  };

  const handleRemoveFavorite = () => {
    if (favoriteToRemove) {
      removeFavoriteMutation.mutate(favoriteToRemove.id);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Mes Favoris"
              subtitle="Accédez rapidement à vos ressources et projets favoris"
            />
            
            <Tabs defaultValue="resources" value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="resources">Ressources</TabsTrigger>
                <TabsTrigger value="projects">Projets</TabsTrigger>
              </TabsList>
              
              <div className="mt-6 mb-6">
                <Input
                  placeholder={`Rechercher ${activeTab === "resources" ? "une ressource" : "un projet"}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <TabsContent value="resources">
                {isLoadingFavorites || isLoadingResources ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                  </div>
                ) : filteredResources.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredResources.map((resource) => (
                      <div key={resource.id} className="group relative">
                        <Card className="overflow-hidden hover:shadow-md transition-shadow">
                          <div className="senegal-pattern h-3"></div>
                          <CardContent className="p-4">
                            <ResourceCard 
                              resource={resource} 
                              onClick={() => handleResourceClick(resource)}
                            />
                          </CardContent>
                        </Card>
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => confirmRemoveResource(resource)}
                        >
                          <i className="ri-delete-bin-line"></i>
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-[#00853F]/10 text-[#00853F] rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-bookmark-line text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">
                      {searchQuery ? "Aucune ressource trouvée" : "Aucune ressource favorite"}
                    </h3>
                    <p className="text-gray-500 mb-6">
                      {searchQuery 
                        ? "Aucune ressource ne correspond à votre recherche" 
                        : "Ajoutez des ressources à vos favoris pour y accéder rapidement."}
                    </p>
                    {!searchQuery && (
                      <Button 
                        className="bg-[#00853F] hover:bg-[#00853F]/90"
                        onClick={() => navigate('/resources')}
                      >
                        <i className="ri-compass-3-line mr-2"></i>
                        Explorer les ressources
                      </Button>
                    )}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="projects">
                {isLoadingFavorites || isLoadingProjects ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                  </div>
                ) : filteredProjects.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProjects.map((project) => (
                      <div key={project.id} className="group relative">
                        <ProjectCard
                          project={project}
                          onView={handleViewProject}
                          onEdit={handleEditProject}
                          onDownload={handleDownloadProject}
                        />
                        <Button
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => confirmRemoveProject(project)}
                        >
                          <i className="ri-delete-bin-line"></i>
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-[#00853F]/10 text-[#00853F] rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-bookmark-line text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">
                      {searchQuery ? "Aucun projet trouvé" : "Aucun projet favori"}
                    </h3>
                    <p className="text-gray-500 mb-6">
                      {searchQuery 
                        ? "Aucun projet ne correspond à votre recherche" 
                        : "Ajoutez des projets à vos favoris pour y accéder rapidement."}
                    </p>
                    {!searchQuery && (
                      <Button 
                        className="bg-[#00853F] hover:bg-[#00853F]/90"
                        onClick={() => navigate('/saved-ideas')}
                      >
                        <i className="ri-folder-line mr-2"></i>
                        Voir mes projets
                      </Button>
                    )}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
      
      {/* Remove Favorite Confirmation Dialog */}
      <Dialog open={!!favoriteToRemove} onOpenChange={(open) => !open && setFavoriteToRemove(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Retirer des favoris</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir retirer cet élément de vos favoris ?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFavoriteToRemove(null)}>
              Annuler
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleRemoveFavorite}
              disabled={removeFavoriteMutation.isPending}
            >
              {removeFavoriteMutation.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Suppression...</>
              ) : (
                "Retirer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
