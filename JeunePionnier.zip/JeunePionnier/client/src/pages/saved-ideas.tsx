import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ProjectCard } from '@/components/project-card';
import { Input } from '@/components/ui/input';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Project } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { Loader2 } from 'lucide-react';
import { generateProjectPdf } from '@/lib/pdf-service';

// Helper to filter projects by search query
const filterProjects = (projects: Project[], searchQuery: string): Project[] => {
  if (!searchQuery) return projects;
  
  const query = searchQuery.toLowerCase();
  return projects.filter(
    project => 
      project.title.toLowerCase().includes(query) ||
      project.description.toLowerCase().includes(query) ||
      project.sector.toLowerCase().includes(query)
  );
};

export default function SavedIdeas() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [_, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);

  // Fetch user's projects
  const { data: projects = [], isLoading, refetch } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    refetchOnWindowFocus: false,
  });

  // Delete project mutation
  const deleteProjectMutation = useMutation({
    mutationFn: async (projectId: number) => {
      await apiRequest('DELETE', `/api/projects/${projectId}`);
    },
    onSuccess: () => {
      refetch();
      toast({
        title: "Projet supprimé",
        description: "Le projet a été supprimé avec succès."
      });
      setProjectToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la suppression : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Filter projects
  const filteredProjects = filterProjects(projects, searchQuery);

  // Project action handlers
  const handleViewProject = (project: Project) => {
    const baseRoute = project.type === 'idea' ? '/idea-generator' :
                      project.type === 'business_plan' ? '/business-plan' :
                      project.type === 'market_research' ? '/market-research' : '/projects';
                      
    navigate(`${baseRoute}/${project.id}`);
  };

  const handleEditProject = (project: Project) => {
    const baseRoute = project.type === 'idea' ? '/idea-generator' :
                      project.type === 'business_plan' ? '/business-plan' :
                      project.type === 'market_research' ? '/market-research' : '/projects';
                      
    navigate(`${baseRoute}/${project.id}/edit`);
  };

  const handleDownloadProject = (project: Project) => {
    // Générer et télécharger le PDF
    try {
      generateProjectPdf(project);
      toast({
        title: "Téléchargement du PDF",
        description: "Votre projet a été téléchargé avec succès.",
      });
    } catch (error) {
      console.error("Erreur lors du téléchargement du PDF:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors du téléchargement. Veuillez réessayer.",
        variant: "destructive"
      });
    }
  };

  const confirmDelete = (project: Project) => {
    setProjectToDelete(project);
  };

  const handleDeleteProject = () => {
    if (projectToDelete) {
      deleteProjectMutation.mutate(projectToDelete.id);
    }
  };

  // Get project counts by type
  const ideaCount = projects.filter(p => p.type === 'idea').length;
  const businessPlanCount = projects.filter(p => p.type === 'business_plan').length;
  const marketResearchCount = projects.filter(p => p.type === 'market_research').length;

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Mes projets sauvegardés"
              subtitle="Consultez et gérez tous vos projets"
              actions={
                <Button 
                  className="bg-[#00853F] hover:bg-[#00853F]/90"
                  onClick={() => navigate('/idea-generator')}
                >
                  <i className="ri-add-line mr-2"></i>
                  Nouveau Projet
                </Button>
              }
            />
            
            {/* Stats Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Idées d'entreprise</p>
                    <p className="text-2xl font-bold">{ideaCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-[#00853F] bg-opacity-10 flex items-center justify-center text-[#00853F]">
                    <i className="ri-lightbulb-line text-xl"></i>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Business Plans</p>
                    <p className="text-2xl font-bold">{businessPlanCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-[#FFCC00] bg-opacity-10 flex items-center justify-center text-[#FFCC00]">
                    <i className="ri-file-chart-line text-xl"></i>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Études de marché</p>
                    <p className="text-2xl font-bold">{marketResearchCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-[#D21034] bg-opacity-10 flex items-center justify-center text-[#D21034]">
                    <i className="ri-pie-chart-line text-xl"></i>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Search & Projects Grid */}
            <div className="mb-6">
              <Input
                placeholder="Rechercher un projet..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="mb-6"
              />
              
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                </div>
              ) : filteredProjects.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProjects.map((project) => (
                    <div key={project.id} className="group relative">
                      <ProjectCard
                        project={project}
                        onView={handleViewProject}
                        onEdit={handleEditProject}
                        onDownload={handleDownloadProject}
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => confirmDelete(project)}
                      >
                        <i className="ri-delete-bin-line"></i>
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-[#00853F]/10 text-[#00853F] rounded-full flex items-center justify-center mx-auto mb-4">
                    <i className="ri-folder-line text-2xl"></i>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">
                    {searchQuery ? "Aucun projet trouvé" : "Vous n'avez pas encore de projets"}
                  </h3>
                  <p className="text-gray-500 mb-6">
                    {searchQuery 
                      ? "Aucun projet ne correspond à votre recherche" 
                      : "Commencez par générer une idée d'entreprise ou créer un business plan"}
                  </p>
                  {!searchQuery && (
                    <Button 
                      className="bg-[#00853F] hover:bg-[#00853F]/90"
                      onClick={() => navigate('/idea-generator')}
                    >
                      <i className="ri-add-line mr-2"></i>
                      Créer votre premier projet
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={!!projectToDelete} onOpenChange={(open) => !open && setProjectToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmer la suppression</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir supprimer le projet "{projectToDelete?.title}" ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProjectToDelete(null)}>
              Annuler
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteProject}
              disabled={deleteProjectMutation.isPending}
            >
              {deleteProjectMutation.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Suppression...</>
              ) : (
                "Supprimer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
