import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Layout } from "@/components/layout/layout";
import { Header } from "@/components/layout/header";
import { Container } from "@/components/layout/container";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FeasibilityStudyForm } from "@/components/feasibility-study-form";
import { ProjectCard } from "@/components/project-card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { FeasibilityStudyInput, Project } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { simpleMarkdownToHtml } from "@/lib/pdf-service";

export default function FeasibilityStudy() {
  const [activeTab, setActiveTab] = useState("new");
  const [resultContent, setResultContent] = useState<string | null>(null);
  const [originalMarkdown, setOriginalMarkdown] = useState<string | null>(null);
  const { toast } = useToast();

  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    select: (data) => data.filter((project) => project.type === "feasibility_study")
  });

  const generateMutation = useMutation({
    mutationFn: async (data: FeasibilityStudyInput) => {
      const res = await apiRequest("POST", "/api/generate-feasibility-study", data);
      return await res.json();
    },
    onSuccess: (data) => {
      if (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) {
        setResultContent(data.choices[0].message.content);
        setOriginalMarkdown(data.original_content || data.choices[0].message.content);
      } else {
        toast({
          title: "Erreur",
          description: "Le format de la réponse est incorrect.",
          variant: "destructive",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la génération",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (projectData: any) => {
      const res = await apiRequest("POST", "/api/projects", projectData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Succès",
        description: "L'étude de faisabilité a été sauvegardée avec succès.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setActiveTab("saved");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la sauvegarde",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (data: FeasibilityStudyInput) => {
    generateMutation.mutate(data);
  };

  const handleSave = (title: string, description: string, sector: string, budget: string) => {
    if (!originalMarkdown) {
      toast({
        title: "Erreur",
        description: "Aucun contenu à sauvegarder.",
        variant: "destructive",
      });
      return;
    }

    const projectData = {
      title,
      description,
      sector,
      budget,
      type: "feasibility_study",
      content: originalMarkdown,
    };

    saveMutation.mutate(projectData);
  };

  const handleViewProject = (project: Project) => {
    const htmlContent = simpleMarkdownToHtml(project.content);
    setResultContent(htmlContent);
    setOriginalMarkdown(project.content);
    setActiveTab("new");
  };

  const handleEditProject = (project: Project) => {
    toast({
      title: "Bientôt disponible",
      description: "L'édition des études de faisabilité sera disponible prochainement.",
    });
  };

  const handleDownloadProject = (project: Project) => {
    import("@/lib/pdf-service").then(({ generateProjectPdf }) => {
      generateProjectPdf(project);
    });
  };

  useEffect(() => {
    if (activeTab === "saved") {
      setResultContent(null);
      setOriginalMarkdown(null);
    }
  }, [activeTab]);

  return (
    <Layout>
      <Container>
        <Header
          title="Étude de Faisabilité"
          subtitle="Évaluez la viabilité de votre projet d'entreprise au Sénégal"
          className="page-header"
        />

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-8">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="new">Nouvelle Étude</TabsTrigger>
            <TabsTrigger value="saved">Études Sauvegardées ({projects.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="new" className="mt-6 space-y-6">
            <FeasibilityStudyForm
              onSubmit={handleSubmit}
              isLoading={generateMutation.isPending}
              studyResult={resultContent}
              onSave={handleSave}
            />
            {resultContent && (
              <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="senegal-pattern h-3"></div>
                <div className="p-6">
                  <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                    <i className="ri-file-text-line text-[#00853F] mr-2"></i>
                    Résultat de l'étude
                  </h2>
                  <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: resultContent }} />
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="saved" className="mt-6">
            {projects.length === 0 ? (
              <Alert>
                <AlertTitle>Aucune étude sauvegardée</AlertTitle>
                <AlertDescription>
                  Générez une étude de faisabilité et sauvegardez-la pour la retrouver ici.
                </AlertDescription>
              </Alert>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projects.map((project) => (
                  <ProjectCard
                    key={project.id}
                    project={project}
                    onView={handleViewProject}
                    onEdit={handleEditProject}
                    onDownload={handleDownloadProject}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </Container>
    </Layout>
  );
}