import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { User, userRoles } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Loader2, ShieldCheck, Users, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function AdminDashboard() {
  const { user: currentUser, isAdmin, isSuperAdmin } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>("pending");
  const [userToApprove, setUserToApprove] = useState<User | null>(null);
  const [userToChangeRole, setUserToChangeRole] = useState<User | null>(null);
  const [selectedRole, setSelectedRole] = useState<string>("user");

  // Fetch users waiting for approval
  const { data: pendingUsers = [], isLoading: isLoadingPending, refetch: refetchPending } = useQuery<User[]>({
    queryKey: ['/api/admin/users/pending'],
    refetchOnWindowFocus: false,
    retry: false,
  });

  // Fetch all users
  const { data: allUsers = [], isLoading: isLoadingAllUsers, refetch: refetchAllUsers } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    refetchOnWindowFocus: false,
    retry: false,
  });

  // Approve user mutation
  const approveUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest('POST', `/api/admin/users/${userId}/approve`);
      return await res.json();
    },
    onSuccess: () => {
      refetchPending();
      refetchAllUsers();
      toast({
        title: "Utilisateur approuvé",
        description: "L'utilisateur a été approuvé avec succès."
      });
      setUserToApprove(null);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de l'approbation : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Change user role mutation
  const changeRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: number; role: string }) => {
      const res = await apiRequest('POST', `/api/admin/users/${userId}/role`, { role });
      return await res.json();
    },
    onSuccess: () => {
      refetchAllUsers();
      toast({
        title: "Rôle modifié",
        description: "Le rôle de l'utilisateur a été modifié avec succès."
      });
      setUserToChangeRole(null);
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la modification du rôle : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Format date helper
  const formatDate = (dateString: string | Date | null) => {
    if (!dateString) return 'Date inconnue';
    const date = new Date(dateString);
    return format(date, 'dd/MM/yyyy à HH:mm', { locale: fr });
  };

  // Handle approve user
  const confirmApproveUser = (user: User) => {
    setUserToApprove(user);
  };

  const handleApproveUser = () => {
    if (userToApprove) {
      approveUserMutation.mutate(userToApprove.id);
    }
  };

  // Handle change role
  const confirmChangeRole = (user: User) => {
    setUserToChangeRole(user);
    setSelectedRole(user.role);
  };

  const handleChangeRole = () => {
    if (userToChangeRole && selectedRole) {
      changeRoleMutation.mutate({ userId: userToChangeRole.id, role: selectedRole });
    }
  };

  // Get stats
  const totalUsers = allUsers.length;
  const pendingApprovalCount = pendingUsers.length;
  const adminCount = allUsers.filter(u => u.role === userRoles.ADMIN || u.role === userRoles.SUPER_ADMIN).length;
  const regularUserCount = allUsers.filter(u => u.role === userRoles.USER).length;

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Administration"
              subtitle={`Bienvenue, ${isSuperAdmin ? 'Super-Administrateur' : 'Administrateur'}`}
            />
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
              <Card>
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Utilisateurs</p>
                    <p className="text-2xl font-bold">{totalUsers}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-700">
                    <Users size={20} />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">En attente</p>
                    <p className="text-2xl font-bold">{pendingApprovalCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-yellow-100 flex items-center justify-center text-yellow-700">
                    <Clock size={20} />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Administrateurs</p>
                    <p className="text-2xl font-bold">{adminCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-[#00853F] bg-opacity-10 flex items-center justify-center text-[#00853F]">
                    <ShieldCheck size={20} />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6 flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Utilisateurs</p>
                    <p className="text-2xl font-bold">{regularUserCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-lg bg-[#FFCC00] bg-opacity-10 flex items-center justify-center text-[#FFCC00]">
                    <i className="ri-user-line text-xl"></i>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Tabs defaultValue="pending" value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="pending">En attente</TabsTrigger>
                <TabsTrigger value="all">Tous les utilisateurs</TabsTrigger>
              </TabsList>
              
              <TabsContent value="pending" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Utilisateurs en attente d'approbation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoadingPending ? (
                      <div className="flex justify-center py-12">
                        <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                      </div>
                    ) : pendingUsers.length > 0 ? (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Nom complet</TableHead>
                              <TableHead>Nom d'utilisateur</TableHead>
                              <TableHead>Email</TableHead>
                              <TableHead>Date d'inscription</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {pendingUsers.map((user) => (
                              <TableRow key={user.id}>
                                <TableCell className="font-medium">{user.fullName}</TableCell>
                                <TableCell>{user.username}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>{formatDate(user.createdAt)}</TableCell>
                                <TableCell>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="border-[#00853F] text-[#00853F]"
                                    onClick={() => confirmApproveUser(user)}
                                  >
                                    <CheckCircle2 className="h-4 w-4 mr-1" />
                                    Approuver
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-12 h-12 bg-green-100 text-green-700 rounded-full flex items-center justify-center mx-auto mb-4">
                          <CheckCircle2 size={24} />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Aucun utilisateur en attente</h3>
                        <p className="text-gray-500">
                          Tous les utilisateurs ont été approuvés.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="all" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Tous les utilisateurs</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {isLoadingAllUsers ? (
                      <div className="flex justify-center py-12">
                        <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                      </div>
                    ) : allUsers.length > 0 ? (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Nom complet</TableHead>
                              <TableHead>Nom d'utilisateur</TableHead>
                              <TableHead>Email</TableHead>
                              <TableHead>Rôle</TableHead>
                              <TableHead>Statut</TableHead>
                              <TableHead>Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {allUsers.map((user) => (
                              <TableRow key={user.id}>
                                <TableCell className="font-medium">{user.fullName}</TableCell>
                                <TableCell>{user.username}</TableCell>
                                <TableCell>{user.email}</TableCell>
                                <TableCell>
                                  <Badge className={
                                    user.role === userRoles.SUPER_ADMIN ? "bg-purple-600" :
                                    user.role === userRoles.ADMIN ? "bg-[#00853F]" :
                                    "bg-gray-500"
                                  }>
                                    {user.role === userRoles.SUPER_ADMIN ? "Super Admin" :
                                     user.role === userRoles.ADMIN ? "Admin" :
                                     "Utilisateur"}
                                  </Badge>
                                </TableCell>
                                <TableCell>
                                  {user.approved ? (
                                    <Badge className="bg-green-600">Approuvé</Badge>
                                  ) : (
                                    <Badge variant="outline" className="text-yellow-600 border-yellow-600">En attente</Badge>
                                  )}
                                </TableCell>
                                <TableCell>
                                  {!user.approved && (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      className="border-[#00853F] text-[#00853F] mr-2"
                                      onClick={() => confirmApproveUser(user)}
                                    >
                                      <CheckCircle2 className="h-4 w-4 mr-1" />
                                      Approuver
                                    </Button>
                                  )}
                                  
                                  {isSuperAdmin && user.id !== currentUser?.id && user.role !== userRoles.SUPER_ADMIN && (
                                    <Button 
                                      variant="outline" 
                                      size="sm"
                                      onClick={() => confirmChangeRole(user)}
                                    >
                                      <Users className="h-4 w-4 mr-1" />
                                      Changer le rôle
                                    </Button>
                                  )}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <div className="w-12 h-12 bg-yellow-100 text-yellow-700 rounded-full flex items-center justify-center mx-auto mb-4">
                          <XCircle size={24} />
                        </div>
                        <h3 className="text-lg font-semibold mb-2">Aucun utilisateur trouvé</h3>
                        <p className="text-gray-500">
                          Il n'y a aucun utilisateur dans le système.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
            
            {/* Admin Guide */}
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Guide de l'administrateur</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <p>
                    En tant qu'administrateur, vous êtes responsable de la gestion des utilisateurs de la plateforme Ndimbal.
                    Voici quelques informations importantes à connaître :
                  </p>
                  
                  <h3>Approbation des utilisateurs</h3>
                  <p>
                    Les nouveaux utilisateurs doivent être approuvés avant de pouvoir utiliser pleinement la plateforme.
                    Utilisez l'onglet "En attente" pour voir et approuver les utilisateurs qui viennent de s'inscrire.
                  </p>
                  
                  <h3>Gestion des rôles</h3>
                  <p>
                    Il existe trois rôles dans le système :
                  </p>
                  <ul>
                    <li><strong>Super Admin :</strong> Accès complet, peut modifier les rôles des autres utilisateurs</li>
                    <li><strong>Admin :</strong> Peut approuver les utilisateurs et gérer les ressources</li>
                    <li><strong>Utilisateur :</strong> Accès standard à la plateforme</li>
                  </ul>
                  
                  <h3>Bonnes pratiques</h3>
                  <p>
                    Vérifiez régulièrement les utilisateurs en attente d'approbation pour assurer une bonne expérience utilisateur.
                    Limitez le nombre d'administrateurs pour maintenir la sécurité de la plateforme.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
      
      {/* Approve User Confirmation Dialog */}
      <Dialog open={!!userToApprove} onOpenChange={(open) => !open && setUserToApprove(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approuver l'utilisateur</DialogTitle>
            <DialogDescription>
              Êtes-vous sûr de vouloir approuver l'utilisateur {userToApprove?.fullName} ({userToApprove?.username}) ?
              Une fois approuvé, il pourra accéder à toutes les fonctionnalités de la plateforme.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUserToApprove(null)}>
              Annuler
            </Button>
            <Button 
              className="bg-[#00853F] hover:bg-[#00853F]/90"
              onClick={handleApproveUser}
              disabled={approveUserMutation.isPending}
            >
              {approveUserMutation.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Approbation...</>
              ) : (
                "Approuver"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Change Role Dialog */}
      <Dialog open={!!userToChangeRole} onOpenChange={(open) => !open && setUserToChangeRole(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Modifier le rôle de l'utilisateur</DialogTitle>
            <DialogDescription>
              Choisissez un nouveau rôle pour {userToChangeRole?.fullName} ({userToChangeRole?.username}).
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Select value={selectedRole} onValueChange={setSelectedRole}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un rôle" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={userRoles.USER}>Utilisateur</SelectItem>
                <SelectItem value={userRoles.ADMIN}>Administrateur</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setUserToChangeRole(null)}>
              Annuler
            </Button>
            <Button 
              className="bg-[#00853F] hover:bg-[#00853F]/90"
              onClick={handleChangeRole}
              disabled={changeRoleMutation.isPending}
            >
              {changeRoleMutation.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Modification...</>
              ) : (
                "Enregistrer"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
