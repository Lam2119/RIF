import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { StatCard } from '@/components/stat-card';
import { ProjectCard } from '@/components/project-card';
import { ResourceCard } from '@/components/resource-card';
import { SectorCard } from '@/components/sector-card';
import { IdeaGeneratorForm } from '@/components/idea-generator-form';
import { Project, Resource } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { generateProjectPdf } from '@/lib/pdf-service';

const trendingSectors = [
  { name: 'Agriculture', growth: '+24%', image: '' },
  { name: 'Technologie', growth: '+32%', image: '' },
  { name: 'Énergie renouvelable', growth: '+45%', image: '' },
  { name: 'Tourisme', growth: '+18%', image: '' },
];

export default function Dashboard() {
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  const [ideaResult, setIdeaResult] = useState<string | null>(null);

  // Fetch user's projects
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    refetchOnWindowFocus: false,
  });

  // Fetch resources
  const { data: resources = [] } = useQuery<Resource[]>({
    queryKey: ['/api/resources'],
    refetchOnWindowFocus: false,
  });

  // Helper functions for project actions
  const handleViewProject = (project: Project) => {
    navigate(`/project/${project.id}`);
  };

  const handleEditProject = (project: Project) => {
    navigate(`/project/${project.id}/edit`);
  };

  const handleDownloadProject = (project: Project) => {
    // Appel de la fonction de génération de PDF
    generateProjectPdf(project);
  };

  // Stats for dashboard
  const stats = [
    {
      title: 'Idées générées',
      value: projects.filter(p => p.type === 'idea').length || 0,
      icon: 'ri-lightbulb-line',
      iconColor: 'text-[#00853F]',
      iconBgColor: 'bg-[#00853F] bg-opacity-10',
      trend: { value: '+33% depuis le mois dernier', isPositive: true }
    },
    {
      title: 'Business plans',
      value: projects.filter(p => p.type === 'business_plan').length || 0,
      icon: 'ri-file-chart-line',
      iconColor: 'text-[#FFCC00]',
      iconBgColor: 'bg-[#FFCC00] bg-opacity-10',
      trend: { value: '+50% depuis le mois dernier', isPositive: true }
    },
    {
      title: 'Études de marché',
      value: projects.filter(p => p.type === 'market_research').length || 0,
      icon: 'ri-pie-chart-line',
      iconColor: 'text-[#D21034]',
      iconBgColor: 'bg-[#D21034] bg-opacity-10',
      trend: { value: '-25% depuis le mois dernier', isPositive: false }
    },
    {
      title: 'Ressources consultées',
      value: 28,
      icon: 'ri-book-open-line',
      iconColor: 'text-purple-500',
      iconBgColor: 'bg-purple-500 bg-opacity-10',
      trend: { value: '+12% depuis le mois dernier', isPositive: true }
    }
  ];

  // Get recent projects
  const recentProjects = projects.slice(0, 3);

  // Get recent resources
  const recentResources = resources.slice(0, 4);

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title={`Bonjour, ${user?.fullName?.split(' ')[0] || 'Utilisateur'} 👋`}
              subtitle="Bienvenue sur votre tableau de bord"
              actions={
                <div className="hidden md:flex space-x-2">
                  <Button variant="outline" className="border-[#00853F] text-[#00853F]">
                    <i className="ri-file-download-line mr-2"></i>Exporter
                  </Button>
                  <Button className="bg-[#00853F] hover:bg-[#00853F]/90" onClick={() => navigate('/idea-generator')}>
                    <i className="ri-add-line mr-2"></i>Nouveau Projet
                  </Button>
                </div>
              }
            />

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
              {stats.map((stat, index) => (
                <StatCard key={index} {...stat} />
              ))}
            </div>

            {/* Feature Blocks */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* AI Idea Generator Block */}
              <div className="col-span-1 lg:col-span-2">
                <IdeaGeneratorForm onResult={setIdeaResult} />
              </div>

              {/* Recent Resources */}
              <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                <div className="senegal-pattern h-3"></div>
                <div className="p-6">
                  <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                    <i className="ri-file-list-3-line text-[#FFCC00] mr-2"></i>
                    Ressources Récentes
                  </h2>
                  
                  <div className="space-y-4">
                    {recentResources.map((resource) => (
                      <ResourceCard 
                        key={resource.id} 
                        resource={resource} 
                        onClick={() => navigate(`/resources/${resource.id}`)}
                      />
                    ))}
                  </div>
                  
                  <div className="mt-4 text-center">
                    <Button 
                      variant="link" 
                      className="text-[#00853F]"
                      onClick={() => navigate('/resources')}
                    >
                      Voir toutes les ressources →
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick Access Tools */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Étude de faisabilité */}
              <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="senegal-pattern h-3"></div>
                <div className="p-6">
                  <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                    <i className="ri-file-text-line text-[#00853F] mr-2"></i>
                    Étude de Faisabilité
                  </h2>
                  <p className="text-gray-600 mb-4">
                    Évaluez la viabilité de votre projet d'entreprise
                  </p>
                  <Button onClick={() => navigate('/feasibility-study')} className="w-full bg-[#00853F] hover:bg-[#00853F]/90">
                    Commencer une étude
                  </Button>
                </div>
              </div>

              {/* Analyse financière */}
              <div className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="senegal-pattern h-3"></div>
                <div className="p-6">
                  <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                    <i className="ri-money-dollar-circle-line text-[#00853F] mr-2"></i>
                    Analyse Financière
                  </h2>
                  <p className="text-gray-600 mb-4">
                    Analysez la rentabilité de votre projet
                  </p>
                  <Button onClick={() => navigate('/financial-analysis')} className="w-full bg-[#00853F] hover:bg-[#00853F]/90">
                    Commencer une analyse
                  </Button>
                </div>
              </div>
            </div>

            {/* Recent Projects */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-montserrat font-bold">Mes Projets Récents</h2>
                <Button 
                  variant="link" 
                  className="text-[#00853F]"
                  onClick={() => navigate('/saved-ideas')}
                >
                  Voir tous
                </Button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {recentProjects.length > 0 ? (
                  recentProjects.map((project) => (
                    <ProjectCard
                      key={project.id}
                      project={project}
                      onView={handleViewProject}
                      onEdit={handleEditProject}
                      onDownload={handleDownloadProject}
                    />
                  ))
                ) : (
                  <div className="col-span-full text-center py-12">
                    <p className="text-gray-500">Vous n'avez pas encore de projets.</p>
                    <Button 
                      className="mt-4 bg-[#00853F] hover:bg-[#00853F]/90"
                      onClick={() => navigate('/idea-generator')}
                    >
                      <i className="ri-add-line mr-2"></i>
                      Créer votre premier projet
                    </Button>
                  </div>
                )}
              </div>
            </div>
            
            {/* Trending Sectors */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-montserrat font-bold">Secteurs tendance au Sénégal</h2>
                <Button 
                  variant="link" 
                  className="text-[#00853F]"
                  onClick={() => navigate('/resources')}
                >
                  Explorer tous les secteurs
                </Button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {trendingSectors.map((sector, index) => (
                  <SectorCard
                    key={index}
                    name={sector.name}
                    growth={sector.growth}
                    image={sector.image}
                    onClick={(name) => navigate(`/idea-generator?sector=${name}`)}
                  />
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
