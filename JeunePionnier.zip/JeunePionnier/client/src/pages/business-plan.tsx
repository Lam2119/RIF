import React, { useState } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ProjectCard } from '@/components/project-card';
import { Project } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { BusinessPlanForm } from '@/components/business-plan-form';
import { createBusinessPlanPrompt, generateWithAI } from '@/lib/openrouter-api';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';
import { generateProjectPdf } from '@/lib/pdf-service';

export default function BusinessPlan() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("create");
  const [isGenerating, setIsGenerating] = useState(false);
  const [businessPlanResult, setBusinessPlanResult] = useState<string | null>(null);
  const [originalMarkdown, setOriginalMarkdown] = useState<string | null>(null);

  // Fetch user's business plans
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    refetchOnWindowFocus: false,
  });

  // Filter only business plans
  const businessPlans = projects.filter(project => project.type === 'business_plan');

  const generateBusinessPlanMutation = useMutation({
    mutationFn: async (data: {
      businessName: string;
      sector: string;
      description: string;
    }) => {
      setIsGenerating(true);
      const prompt = createBusinessPlanPrompt(
        data.businessName,
        data.sector,
        data.description
      );
      return await generateWithAI(prompt);
    },
    onSuccess: (result) => {
      // Stocke le contenu affiché et le contenu original en Markdown
      setBusinessPlanResult(result.content);
      setOriginalMarkdown(result.originalMarkdown || null);
      setIsGenerating(false);
      toast({
        title: "Business plan généré",
        description: "Le business plan a été généré avec succès. Vous pouvez maintenant le sauvegarder.",
      });
    },
    onError: (error) => {
      setIsGenerating(false);
      toast({
        title: "Erreur",
        description: `Erreur lors de la génération : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const saveBusinessPlanMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      description: string;
      sector: string;
      budget: string;
      content: string;
    }) => {
      const res = await apiRequest('POST', '/api/projects', {
        ...data,
        type: 'business_plan',
        progress: 40
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      toast({
        title: "Business plan sauvegardé",
        description: "Votre business plan a été sauvegardé avec succès.",
      });
      setActiveTab("myPlans");
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la sauvegarde : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleFormSubmit = async (data: {
    businessName: string;
    sector: string;
    description: string;
  }) => {
    generateBusinessPlanMutation.mutate(data);
  };

  const handleSaveBusinessPlan = (title: string, description: string, sector: string, budget: string) => {
    if (!businessPlanResult) return;
    
    // Utiliser le contenu original en Markdown s'il est disponible
    const contentToSave = originalMarkdown || businessPlanResult;
    
    saveBusinessPlanMutation.mutate({
      title,
      description,
      sector,
      budget,
      content: contentToSave
    });
  };

  // Helper functions for business plan actions
  const handleViewBusinessPlan = (project: Project) => {
    navigate(`/business-plan/${project.id}`);
  };

  const handleEditBusinessPlan = (project: Project) => {
    navigate(`/business-plan/${project.id}/edit`);
  };

  const handleDownloadBusinessPlan = (project: Project) => {
    // Générer et télécharger le PDF
    try {
      generateProjectPdf(project);
      toast({
        title: "Téléchargement du PDF",
        description: "Votre business plan a été téléchargé avec succès.",
      });
    } catch (error) {
      console.error("Erreur lors du téléchargement du PDF:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors du téléchargement. Veuillez réessayer.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Business Plans"
              subtitle="Créez des plans d'affaires professionnels pour votre entreprise"
            />
            
            <Tabs defaultValue="create" value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="create">Créer un business plan</TabsTrigger>
                <TabsTrigger value="myPlans">Mes business plans</TabsTrigger>
              </TabsList>
              
              <TabsContent value="create" className="mt-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <BusinessPlanForm 
                      onSubmit={handleFormSubmit} 
                      isLoading={isGenerating}
                      businessPlanResult={businessPlanResult}
                      onSave={handleSaveBusinessPlan}
                    />
                  </div>
                  
                  <div>
                    {isGenerating ? (
                      <Card className="flex items-center justify-center h-full min-h-[400px]">
                        <div className="text-center p-6">
                          <Loader2 className="h-12 w-12 animate-spin text-[#00853F] mx-auto mb-4" />
                          <h3 className="text-xl font-semibold mb-2">Génération en cours...</h3>
                          <p className="text-gray-500">
                            Nous générons votre business plan. Cela peut prendre quelques instants.
                          </p>
                        </div>
                      </Card>
                    ) : businessPlanResult ? (
                      <Card>
                        <div className="h-3 bg-[#FFCC00]"></div>
                        <CardContent className="p-6">
                          <h3 className="font-montserrat font-bold text-lg mb-4">Business Plan Généré</h3>
                          <div className="max-h-[600px] overflow-y-auto prose prose-sm">
                            <div className="whitespace-pre-line">
                              {businessPlanResult}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ) : (
                      <Card className="flex items-center justify-center h-full min-h-[400px]">
                        <div className="text-center p-6">
                          <div className="w-16 h-16 bg-[#FFCC00]/10 text-[#FFCC00] rounded-full flex items-center justify-center mx-auto mb-4">
                            <i className="ri-file-chart-line text-2xl"></i>
                          </div>
                          <h3 className="text-xl font-semibold mb-2">Prêt à créer votre business plan?</h3>
                          <p className="text-gray-500 mb-6">
                            Remplissez le formulaire à gauche pour générer un business plan adapté à votre projet.
                          </p>
                          <p className="text-sm text-gray-400">
                            Votre business plan généré apparaîtra ici.
                          </p>
                        </div>
                      </Card>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="myPlans" className="mt-6">
                {isLoadingProjects ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                  </div>
                ) : businessPlans.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {businessPlans.map((plan) => (
                      <ProjectCard
                        key={plan.id}
                        project={plan}
                        onView={handleViewBusinessPlan}
                        onEdit={handleEditBusinessPlan}
                        onDownload={handleDownloadBusinessPlan}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-[#FFCC00]/10 text-[#FFCC00] rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-file-chart-line text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Aucun business plan trouvé</h3>
                    <p className="text-gray-500 mb-6">
                      Vous n'avez pas encore créé de business plan.
                    </p>
                    <Button 
                      className="bg-[#00853F] hover:bg-[#00853F]/90"
                      onClick={() => setActiveTab("create")}
                    >
                      <i className="ri-add-line mr-2"></i>
                      Créer un business plan
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
            
            {/* Guide Section */}
            <div className="mt-8">
              <h2 className="text-xl font-montserrat font-bold mb-4">Pourquoi créer un business plan?</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#00853F] bg-opacity-10 flex items-center justify-center text-[#00853F] mb-4">
                      <i className="ri-bank-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Accès au financement</h3>
                    <p className="text-gray-600 text-sm">
                      Un business plan bien structuré est essentiel pour convaincre les investisseurs et institutions financières.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#FFCC00] bg-opacity-10 flex items-center justify-center text-[#FFCC00] mb-4">
                      <i className="ri-road-map-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Feuille de route claire</h3>
                    <p className="text-gray-600 text-sm">
                      Il sert de guide pour votre entreprise, définissant vos objectifs et la stratégie pour les atteindre.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#D21034] bg-opacity-10 flex items-center justify-center text-[#D21034] mb-4">
                      <i className="ri-shield-check-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Anticipation des risques</h3>
                    <p className="text-gray-600 text-sm">
                      En élaborant votre plan, vous identifiez les défis potentiels et préparez des stratégies pour y faire face.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
