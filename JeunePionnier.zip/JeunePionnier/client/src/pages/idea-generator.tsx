import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { IdeaGeneratorForm } from '@/components/idea-generator-form';
import { apiRequest } from '@/lib/queryClient';
import { insertProjectSchema } from '@shared/schema';

export default function IdeaGenerator() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchParams] = useLocation();
  const [ideaResult, setIdeaResult] = useState<string | null>(null);
  const [originalMarkdown, setOriginalMarkdown] = useState<string | null>(null);
  const [projectTitle, setProjectTitle] = useState<string>('');

  const saveProjectMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      description: string;
      sector: string;
      type: string;
      content: string;
    }) => {
      const res = await apiRequest('POST', '/api/projects', data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      toast({
        title: "Idée sauvegardée",
        description: "Votre idée a été sauvegardée avec succès."
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la sauvegarde : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleIdeaGenerated = (result: string, originalMarkdown?: string) => {
    setIdeaResult(result);
    
    // Si originalMarkdown est fourni, nous l'utiliserons pour stocker les données
    // mais utiliserons seulement result pour l'affichage
    if (originalMarkdown) {
      // Stocker le markdown original dans l'état et aussi dans un élément caché
      setOriginalMarkdown(originalMarkdown);
      const hiddenElement = document.getElementById('original-markdown-content');
      if (hiddenElement) {
        hiddenElement.setAttribute('data-content', originalMarkdown);
      }
    }
    
    // Extract a potential title from the first line of the result
    const firstLine = result.split('\n')[0];
    if (firstLine) {
      setProjectTitle(firstLine.replace(/^[#\s]+/g, '').slice(0, 50));
    }
  };

  const handleSaveIdea = () => {
    if (!ideaResult) return;
    
    // Extract sector and description from the form
    const sector = ideaResult.toLowerCase().includes('agriculture') ? 'Agriculture' :
                   ideaResult.toLowerCase().includes('technologie') ? 'Technologie' :
                   ideaResult.toLowerCase().includes('commerce') ? 'Commerce' :
                   ideaResult.toLowerCase().includes('artisanat') ? 'Artisanat' :
                   ideaResult.toLowerCase().includes('éducation') || ideaResult.toLowerCase().includes('education') ? 'Education' :
                   ideaResult.toLowerCase().includes('santé') || ideaResult.toLowerCase().includes('sante') ? 'Santé' :
                   ideaResult.toLowerCase().includes('tourisme') ? 'Tourisme' : 'Autre';
    
    const description = ideaResult.split('\n').slice(0, 3).join(' ').slice(0, 200);
    
    // Utiliser le contenu markdown original de l'état si disponible, sinon utiliser ideaResult
    const contentToSave = originalMarkdown || ideaResult;
    
    saveProjectMutation.mutate({
      title: projectTitle,
      description,
      sector,
      type: 'idea',
      content: contentToSave
    });
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Générateur d'idées d'entreprise"
              subtitle="Trouvez des idées innovantes adaptées au marché sénégalais"
            />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              {/* AI Idea Generator Form */}
              <div className="lg:col-span-1">
                <IdeaGeneratorForm onResult={handleIdeaGenerated} />
              </div>
              
              {/* Results Display */}
              <div className="lg:col-span-2">
                {ideaResult ? (
                  <Card className="hover:shadow-md transition-shadow">
                    <div className="h-3 bg-[#00853F]"></div>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-montserrat font-bold flex items-center">
                          <i className="ri-lightbulb-flash-line text-[#FFCC00] mr-2"></i>
                          Résultat de la génération
                        </h2>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline"
                            className="border-[#00853F] text-[#00853F]"
                            onClick={() => setIdeaResult(null)}
                          >
                            <i className="ri-refresh-line mr-2"></i>
                            Nouvelle idée
                          </Button>
                          <Button 
                            className="bg-[#00853F] hover:bg-[#00853F]/90"
                            onClick={handleSaveIdea}
                            disabled={saveProjectMutation.isPending}
                          >
                            {saveProjectMutation.isPending ? (
                              <><i className="ri-loader-4-line animate-spin mr-2"></i>Sauvegarde...</>
                            ) : (
                              <><i className="ri-save-line mr-2"></i>Sauvegarder</>
                            )}
                          </Button>
                        </div>
                      </div>

                      <div className="mb-4">
                        <label className="block text-sm font-medium mb-1">Titre du projet</label>
                        <Textarea 
                          value={projectTitle}
                          onChange={(e) => setProjectTitle(e.target.value)}
                          className="resize-none"
                          placeholder="Titre de votre idée"
                          rows={1}
                        />
                      </div>

                      <Accordion type="single" collapsible defaultValue="item-1">
                        <AccordionItem value="item-1">
                          <AccordionTrigger className="text-[#00853F] font-semibold">Idée générée</AccordionTrigger>
                          <AccordionContent>
                            <div className="mt-4 whitespace-pre-line prose">
                              {ideaResult}
                              {/* Élément caché pour stocker le Markdown original */}
                              <div id="original-markdown-content" style={{display: 'none'}}></div>
                            </div>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="flex items-center justify-center h-full min-h-[400px] hover:shadow-md transition-shadow">
                    <div className="text-center p-6">
                      <div className="w-16 h-16 bg-[#00853F]/10 text-[#00853F] rounded-full flex items-center justify-center mx-auto mb-4">
                        <i className="ri-lightbulb-line text-2xl"></i>
                      </div>
                      <h3 className="text-xl font-semibold mb-2">Prêt à générer votre idée d'entreprise?</h3>
                      <p className="text-gray-500 mb-6">
                        Utilisez le formulaire pour générer une idée adaptée au marché sénégalais.
                      </p>
                      <p className="text-sm text-gray-400">
                        L'idée générée apparaîtra ici.
                      </p>
                    </div>
                  </Card>
                )}
              </div>
            </div>
            
            {/* Guide Section */}
            <div className="mt-8">
              <h2 className="text-xl font-montserrat font-bold mb-4">Guide pour le générateur d'idées</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#00853F] bg-opacity-10 flex items-center justify-center text-[#00853F] mb-4">
                      <i className="ri-compass-3-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Choisissez bien votre secteur</h3>
                    <p className="text-gray-600 text-sm">
                      Sélectionnez un secteur qui correspond à vos intérêts, vos compétences ou qui présente des opportunités au Sénégal.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#FFCC00] bg-opacity-10 flex items-center justify-center text-[#FFCC00] mb-4">
                      <i className="ri-coins-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Définissez votre budget</h3>
                    <p className="text-gray-600 text-sm">
                      Soyez réaliste quant à vos moyens financiers. L'IA proposera des idées adaptées à votre budget.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#D21034] bg-opacity-10 flex items-center justify-center text-[#D21034] mb-4">
                      <i className="ri-edit-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Décrivez votre vision</h3>
                    <p className="text-gray-600 text-sm">
                      Plus vous serez précis dans la description de votre vision, plus l'IA pourra générer une idée qui vous correspond.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
