import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResourceCard } from '@/components/resource-card';
import { SectorCard } from '@/components/sector-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Resource } from '@shared/schema';
import { Loader2 } from 'lucide-react';

const sectors = [
  { name: 'Agriculture', growth: '+24%', image: '' },
  { name: 'Technologie', growth: '+32%', image: '' },
  { name: 'Commerce', growth: '+15%', image: '' },
  { name: 'Artisanat', growth: '+10%', image: '' },
  { name: 'Education', growth: '+20%', image: '' },
  { name: 'Santé', growth: '+28%', image: '' },
  { name: 'Tourisme', growth: '+18%', image: '' },
  { name: 'Énergie renouvelable', growth: '+45%', image: '' },
];

const resourceTypes = [
  { value: 'all', label: 'Tous les types' },
  { value: 'document', label: 'Documents' },
  { value: 'guide', label: 'Guides' },
  { value: 'video', label: 'Vidéos' },
  { value: 'link', label: 'Liens utiles' },
];

export default function Resources() {
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  const [selectedSector, setSelectedSector] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Fetch resources
  const { data: resources = [], isLoading } = useQuery<Resource[]>({
    queryKey: ['/api/resources', selectedSector],
    queryFn: async ({ queryKey }) => {
      const [_, sector] = queryKey;
      const url = sector 
        ? `/api/resources?sector=${encodeURIComponent(sector as string)}` 
        : '/api/resources';
      
      const response = await fetch(url, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Erreur lors de la récupération des ressources');
      }
      
      return response.json();
    },
    refetchOnWindowFocus: false,
  });

  const filteredResources = resources.filter(resource => {
    let matchesType = selectedType === 'all' || resource.type === selectedType;
    let matchesSearch = !searchQuery || 
      resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesType && matchesSearch;
  });

  const handleResourceClick = (resource: Resource) => {
    // Navigate to resource detail page or open URL if available
    if (resource.url) {
      window.open(resource.url, '_blank');
    } else {
      navigate(`/resources/${resource.id}`);
    }
  };

  const handleSectorSelect = (sectorName: string) => {
    setSelectedSector(prevSector => prevSector === sectorName ? null : sectorName);
  };

  const clearFilters = () => {
    setSelectedSector(null);
    setSelectedType('all');
    setSearchQuery('');
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Ressources"
              subtitle="Découvrez des ressources utiles pour les entrepreneurs au Sénégal"
            />
            
            <Tabs defaultValue="resources" className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="resources">Ressources</TabsTrigger>
                <TabsTrigger value="sectors">Secteurs d'activité</TabsTrigger>
              </TabsList>
              
              <TabsContent value="resources" className="mt-6">
                <div className="mb-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Filtres</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-col md:flex-row gap-4">
                        <div className="flex-1">
                          <Input
                            placeholder="Rechercher une ressource..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full"
                          />
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {resourceTypes.map((type) => (
                            <Badge
                              key={type.value}
                              variant={selectedType === type.value ? "default" : "outline"}
                              className={`cursor-pointer ${selectedType === type.value ? "bg-[#00853F]" : ""}`}
                              onClick={() => setSelectedType(type.value)}
                            >
                              {type.label}
                            </Badge>
                          ))}
                        </div>
                        {(selectedSector || selectedType !== 'all' || searchQuery) && (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={clearFilters}
                            className="whitespace-nowrap"
                          >
                            <i className="ri-filter-off-line mr-2"></i>
                            Effacer les filtres
                          </Button>
                        )}
                      </div>
                      
                      {selectedSector && (
                        <div className="mt-4 flex items-center">
                          <span className="text-sm text-gray-500 mr-2">Secteur:</span>
                          <Badge className="bg-[#00853F]">
                            {selectedSector} <i className="ri-close-line ml-1 cursor-pointer" onClick={() => setSelectedSector(null)}></i>
                          </Badge>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-[#00853F]" />
                  </div>
                ) : filteredResources.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredResources.map((resource) => (
                      <Card key={resource.id} className="overflow-hidden hover:shadow-md transition-shadow">
                        <div className="senegal-pattern h-3"></div>
                        <CardContent className="p-4">
                          <ResourceCard 
                            resource={resource} 
                            onClick={handleResourceClick}
                          />
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-[#00853F]/10 text-[#00853F] rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-file-search-line text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Aucune ressource trouvée</h3>
                    <p className="text-gray-500">
                      Aucune ressource ne correspond à vos critères de recherche.
                    </p>
                    <Button 
                      variant="outline" 
                      className="mt-4" 
                      onClick={clearFilters}
                    >
                      Réinitialiser les filtres
                    </Button>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="sectors" className="mt-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {sectors.map((sector) => (
                    <SectorCard
                      key={sector.name}
                      name={sector.name}
                      growth={sector.growth}
                      image={sector.image}
                      onClick={() => {
                        setSelectedSector(sector.name);
                        // Switch to resources tab to show filtered results
                        document.querySelector('[data-state="inactive"][value="resources"]')?.click();
                      }}
                    />
                  ))}
                </div>
                
                <div className="mt-8">
                  <h2 className="text-xl font-montserrat font-bold mb-4">Guide des secteurs d'activité</h2>
                  
                  <Card>
                    <CardContent className="p-6">
                      <div className="prose max-w-none">
                        <p>
                          Le Sénégal offre de nombreuses opportunités d'affaires dans divers secteurs. 
                          Voici quelques informations clés pour vous aider à mieux comprendre les secteurs porteurs:
                        </p>
                        
                        <h3>Agriculture et Agroalimentaire</h3>
                        <p>
                          L'agriculture représente environ 15% du PIB du Sénégal et emploie près de 70% de la population active. 
                          Le pays est connu pour ses cultures d'arachide, de riz, de mil, de maïs, et ses fruits tropicaux.
                          Les opportunités se trouvent dans la transformation des produits agricoles, l'exportation de produits bio, 
                          et l'agriculture moderne et durable.
                        </p>
                        
                        <h3>Technologies et Services Numériques</h3>
                        <p>
                          Le Sénégal est considéré comme l'un des hubs technologiques de l'Afrique de l'Ouest. 
                          Le secteur des TIC connaît une croissance annuelle de plus de 30%. 
                          Les opportunités incluent le développement d'applications mobiles, l'e-commerce, les fintech, 
                          et les solutions pour l'agriculture, l'éducation et la santé.
                        </p>
                        
                        <h3>Énergie Renouvelable</h3>
                        <p>
                          Avec un ensoleillement exceptionnel et des ressources éoliennes importantes, 
                          le Sénégal mise sur les énergies renouvelables pour atteindre ses objectifs énergétiques. 
                          Les opportunités se trouvent dans l'installation de systèmes solaires, 
                          la maintenance d'équipements, et les solutions d'efficacité énergétique.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </main>
      </div>
    </div>
  );
}
