import React, { useState } from 'react';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Sidebar } from '@/components/layout/sidebar';
import { MobileHeader } from '@/components/layout/mobile-sidebar';
import { Header } from '@/components/layout/header';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ProjectCard } from '@/components/project-card';
import { Project } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { MarketResearchForm } from '@/components/market-research-form';
import { createMarketResearchPrompt, generateWithAI } from '@/lib/openrouter-api';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';
import { generateProjectPdf } from '@/lib/pdf-service';

export default function MarketResearch() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [location, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("create");
  const [isGenerating, setIsGenerating] = useState(false);
  const [researchResult, setResearchResult] = useState<string | null>(null);
  const [originalMarkdown, setOriginalMarkdown] = useState<string | null>(null);

  // Fetch user's market research projects
  const { data: projects = [], isLoading: isLoadingProjects } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
    refetchOnWindowFocus: false,
  });

  // Filter only market research projects
  const marketResearchProjects = projects.filter(project => project.type === 'market_research');

  const generateResearchMutation = useMutation({
    mutationFn: async (data: {
      sector: string;
      product: string;
      region: string;
    }) => {
      setIsGenerating(true);
      const prompt = createMarketResearchPrompt(
        data.sector,
        data.product,
        data.region
      );
      return await generateWithAI(prompt);
    },
    onSuccess: (result) => {
      // Stocke le contenu affiché et le contenu original en Markdown
      setResearchResult(result.content);
      setOriginalMarkdown(result.originalMarkdown || null);
      setIsGenerating(false);
      toast({
        title: "Étude de marché générée",
        description: "L'étude de marché a été générée avec succès. Vous pouvez maintenant la sauvegarder.",
      });
    },
    onError: (error) => {
      setIsGenerating(false);
      toast({
        title: "Erreur",
        description: `Erreur lors de la génération : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const saveResearchMutation = useMutation({
    mutationFn: async (data: {
      title: string;
      description: string;
      sector: string;
      region: string;
      content: string;
    }) => {
      const res = await apiRequest('POST', '/api/projects', {
        ...data,
        type: 'market_research',
        progress: 50
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      toast({
        title: "Étude de marché sauvegardée",
        description: "Votre étude de marché a été sauvegardée avec succès.",
      });
      setActiveTab("myResearch");
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: `Erreur lors de la sauvegarde : ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleFormSubmit = async (data: {
    sector: string;
    product: string;
    region: string;
  }) => {
    generateResearchMutation.mutate(data);
  };

  const handleSaveResearch = (title: string, description: string, sector: string, region: string) => {
    if (!researchResult) return;
    
    // Utiliser le contenu original en Markdown s'il est disponible
    const contentToSave = originalMarkdown || researchResult;
    
    saveResearchMutation.mutate({
      title,
      description,
      sector,
      region,
      content: contentToSave
    });
  };

  // Helper functions for project actions
  const handleViewProject = (project: Project) => {
    navigate(`/market-research/${project.id}`);
  };

  const handleEditProject = (project: Project) => {
    navigate(`/market-research/${project.id}/edit`);
  };

  const handleDownloadProject = (project: Project) => {
    // Générer et télécharger le PDF
    try {
      generateProjectPdf(project);
      toast({
        title: "Téléchargement du PDF",
        description: "Votre étude de marché a été téléchargée avec succès.",
      });
    } catch (error) {
      console.error("Erreur lors du téléchargement du PDF:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors du téléchargement. Veuillez réessayer.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <div className="p-6 max-w-7xl mx-auto">
            <Header 
              title="Études de marché"
              subtitle="Analysez votre marché cible avec des données pertinentes au Sénégal"
            />
            
            <Tabs defaultValue="create" value={activeTab} onValueChange={setActiveTab} className="w-full mb-6">
              <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
                <TabsTrigger value="create">Créer une étude</TabsTrigger>
                <TabsTrigger value="myResearch">Mes études</TabsTrigger>
              </TabsList>
              
              <TabsContent value="create" className="mt-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <MarketResearchForm 
                      onSubmit={handleFormSubmit} 
                      isLoading={isGenerating}
                      researchResult={researchResult}
                      onSave={handleSaveResearch}
                    />
                  </div>
                  
                  <div>
                    {isGenerating ? (
                      <Card className="flex items-center justify-center h-full min-h-[400px]">
                        <div className="text-center p-6">
                          <Loader2 className="h-12 w-12 animate-spin text-[#D21034] mx-auto mb-4" />
                          <h3 className="text-xl font-semibold mb-2">Génération en cours...</h3>
                          <p className="text-gray-500">
                            Nous générons votre étude de marché. Cela peut prendre quelques instants.
                          </p>
                        </div>
                      </Card>
                    ) : researchResult ? (
                      <Card>
                        <div className="h-3 bg-[#D21034]"></div>
                        <CardContent className="p-6">
                          <h3 className="font-montserrat font-bold text-lg mb-4">Étude de Marché Générée</h3>
                          <div className="max-h-[600px] overflow-y-auto prose prose-sm">
                            <div className="whitespace-pre-line">
                              {researchResult}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ) : (
                      <Card className="flex items-center justify-center h-full min-h-[400px]">
                        <div className="text-center p-6">
                          <div className="w-16 h-16 bg-[#D21034]/10 text-[#D21034] rounded-full flex items-center justify-center mx-auto mb-4">
                            <i className="ri-pie-chart-line text-2xl"></i>
                          </div>
                          <h3 className="text-xl font-semibold mb-2">Prêt à analyser votre marché?</h3>
                          <p className="text-gray-500 mb-6">
                            Remplissez le formulaire à gauche pour générer une étude de marché adaptée à votre projet.
                          </p>
                          <p className="text-sm text-gray-400">
                            Votre étude de marché générée apparaîtra ici.
                          </p>
                        </div>
                      </Card>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="myResearch" className="mt-6">
                {isLoadingProjects ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-[#D21034]" />
                  </div>
                ) : marketResearchProjects.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {marketResearchProjects.map((project) => (
                      <ProjectCard
                        key={project.id}
                        project={project}
                        onView={handleViewProject}
                        onEdit={handleEditProject}
                        onDownload={handleDownloadProject}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-[#D21034]/10 text-[#D21034] rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-search-line text-2xl"></i>
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Aucune étude de marché trouvée</h3>
                    <p className="text-gray-500 mb-6">
                      Vous n'avez pas encore créé d'étude de marché.
                    </p>
                    <Button 
                      className="bg-[#00853F] hover:bg-[#00853F]/90"
                      onClick={() => setActiveTab("create")}
                    >
                      <i className="ri-add-line mr-2"></i>
                      Créer une étude de marché
                    </Button>
                  </div>
                )}
              </TabsContent>
            </Tabs>
            
            {/* Guide Section */}
            <div className="mt-8">
              <h2 className="text-xl font-montserrat font-bold mb-4">L'importance des études de marché</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#00853F] bg-opacity-10 flex items-center justify-center text-[#00853F] mb-4">
                      <i className="ri-user-search-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Connaître vos clients</h3>
                    <p className="text-gray-600 text-sm">
                      Identifiez précisément qui sont vos clients potentiels et leurs besoins réels.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#FFCC00] bg-opacity-10 flex items-center justify-center text-[#FFCC00] mb-4">
                      <i className="ri-spy-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Analyser la concurrence</h3>
                    <p className="text-gray-600 text-sm">
                      Comprenez qui sont vos concurrents, leurs forces et leurs faiblesses.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <div className="h-10 w-10 rounded-lg bg-[#D21034] bg-opacity-10 flex items-center justify-center text-[#D21034] mb-4">
                      <i className="ri-funds-line text-xl"></i>
                    </div>
                    <h3 className="font-semibold text-lg mb-2">Réduire les risques</h3>
                    <p className="text-gray-600 text-sm">
                      Minimisez les risques d'échec en vérifiant la viabilité de votre projet avant de vous lancer.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
