// Function to call the OpenRouter API via our backend proxy
export async function generateWithAI(prompt: string): Promise<{ content: string, originalMarkdown?: string }> {
  try {
    const response = await fetch('/api/openrouter', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      const errorMessage = errorData?.message || `Erreur API: ${response.status}`;
      throw new Error(errorMessage);
    }

    const data = await response.json();
    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error("Format de réponse invalide de l'API");
    }

    // Retourne le contenu nettoyé pour l'affichage et le contenu original pour le stockage
    return {
      content: data.choices[0].message.content,
      originalMarkdown: data.original_content // contenu avec les marqueurs markdown
    };
  } catch (error) {
    console.error('Erreur lors de l\'appel à l\'API OpenRouter:', error);
    throw error;
  }
}

// Helper to create a prompt for business idea generation
export function createBusinessIdeaPrompt(
  sector: string, 
  budget: string, 
  vision?: string
) {
  let prompt = `Je vais t'aider à générer une idée d'entreprise innovante et détaillée pour le secteur "${sector}" au Sénégal avec un budget initial de ${budget}.`;

  if (vision) {
    prompt += `\n\nVision de l'entrepreneur:\n"${vision}"`;
  }

  prompt += `\n\nGénère une réponse complète en français qui inclut les sections suivantes :

**1. Résumé de l'idée**
[Un résumé concis et percutant de 200 mots maximum qui présente:]
• Le nom proposé pour l'entreprise (en gras)
• Le concept principal
• La proposition de valeur unique
• L'opportunité de marché au Sénégal
• L'innovation apportée

**2. Description détaillée du concept**
• Description approfondie du produit/service
• Caractéristiques innovantes et différenciatrices
• Intégration dans l'écosystème entrepreneurial sénégalais
• Technologies ou approches novatrices utilisées
• Avantages compétitifs dans le contexte local

**3. Public cible et besoins**
• Segments de clientèle principaux (avec données démographiques)
• Besoins non satisfaits sur le marché sénégalais
• Problèmes résolus pour les clients
• Bénéfices tangibles pour les utilisateurs
• Taille du marché potentiel au Sénégal

**4. Modèle économique**
• Sources de revenus diversifiées
• Structure de prix adaptée au marché local
• Stratégie de rentabilité
• Canaux de distribution au Sénégal
• Partenariats stratégiques potentiels

**5. Ressources nécessaires**
• Budget initial détaillé (en FCFA)
• Équipements et matériel requis
• Compétences et expertise nécessaires
• Locaux et infrastructures
• Ressources humaines à mobiliser

**6. Défis et solutions**
• Obstacles réglementaires au Sénégal
• Défis technologiques
• Contraintes du marché local
• Risques identifiés
• Stratégies d'atténuation proposées

**7. Plan de mise en œuvre**
• Phases de développement
• Calendrier détaillé
• Jalons clés
• Indicateurs de performance (KPIs)
• Plan de croissance

**8. Impact socio-économique**
• Création d'emplois directs/indirects
• Contribution au développement local
• Impact environnemental
• Innovation sociale
• Alignement avec les ODD

Adapte bien la réponse au contexte sénégalais en:
- Utilisant des exemples locaux pertinents
- Citant des acteurs du marché quand c'est pertinent
- Mentionnant des zones géographiques spécifiques
- Intégrant des aspects culturels appropriés
- Respectant les réalités économiques locales

Formate le texte pour une lecture agréable avec:
- Des titres en gras
- Des listes à puces
- Des paragraphes bien structurés
- Des transitions logiques entre les sections
- Une mise en forme professionnelle`;

  return prompt;
}

// Helper to create a prompt for business plan generation
export function createBusinessPlanPrompt(
  businessName: string,
  sector: string,
  description: string
) {
  const prompt = `Génère un business plan professionnel, approfondi et ancré dans la réalité sénégalaise pour une entreprise nommée "${businessName}" dans le secteur "${sector}". Voici la description de l'entreprise: "${description}".

Tu dois créer un plan d'affaires qui:
- Est véritablement adapté aux spécificités du marché sénégalais en 2024
- Intègre les réalités économiques, juridiques, fiscales et culturelles du Sénégal
- Propose des stratégies réalistes et applicables localement
- Contient des données précises sur le marché sénégalais quand c'est pertinent
- Prend en compte les infrastructures et ressources disponibles au Sénégal
- Présente une analyse financière adaptée à l'économie locale (en FCFA)
- Identifie des opportunités de financement spécifiques au Sénégal

Ta réponse doit être en français et structurée avec les sections suivantes (utilise des titres en gras):

**1. Résumé exécutif**
- Présentation concise de l'entreprise et de sa proposition de valeur unique
- Opportunité de marché spécifique au Sénégal
- Aperçu des avantages concurrentiels dans le contexte local
- Résumé financier (investissement initial, projections, rentabilité)
- Vision à long terme pour l'impact au Sénégal

**2. Description de l'entreprise**
- Mission et vision dans le contexte sénégalais
- Statut juridique adapté à la législation sénégalaise
- Structure de propriété et gouvernance
- Produits/services et ce qui les rend adaptés au marché local
- Localisation stratégique au Sénégal (avec justification)

**3. Analyse du marché sénégalais**
- Taille et dynamiques du marché avec des données spécifiques au Sénégal
- Segmentation détaillée des clients dans le contexte local
- Analyse de la concurrence directe et indirecte sur le marché sénégalais
- Opportunités et menaces spécifiques au Sénégal
- Tendances et évolutions du secteur au niveau national et régional

**4. Stratégie marketing**
- Positionnement adapté aux valeurs culturelles sénégalaises
- Mix marketing contextuel (4P adaptés au marché local)
- Stratégie de prix tenant compte du pouvoir d'achat sénégalais
- Canaux de communication et de distribution pertinents localement
- Stratégies d'acquisition et de fidélisation adaptées aux consommateurs sénégalais

**5. Plan opérationnel**
- Processus de production/prestation adaptés aux infrastructures locales
- Chaîne d'approvisionnement optimisée pour le contexte sénégalais
- Besoins en équipements et technologies disponibles localement
- Gestion de la qualité selon les normes applicables au Sénégal
- Stratégies pour surmonter les défis opérationnels locaux (électricité, logistique, etc.)

**6. Structure organisationnelle**
- Équipe de direction et compétences clés
- Besoins en personnel et stratégie de recrutement local
- Formation et développement des compétences
- Politique salariale adaptée au marché de l'emploi sénégalais
- Partenariats stratégiques avec des acteurs locaux

**7. Projection financière**
- Investissement initial détaillé (en FCFA)
- Prévisions de revenus sur 3 ans (avec justifications)
- Analyse du seuil de rentabilité dans le contexte économique sénégalais
- Stratégie de financement adaptée aux options disponibles au Sénégal
- Indicateurs financiers clés et ratios pertinents

**8. Analyse des risques**
- Risques spécifiques au marché sénégalais
- Défis réglementaires propres au Sénégal
- Stratégies d'atténuation contextuelles
- Plan de contingence adapté aux réalités locales
- Analyse SWOT approfondie dans le contexte sénégalais

**9. Chronologie de mise en œuvre**
- Calendrier détaillé des actions sur 18-24 mois
- Jalons clés et indicateurs de succès
- Phases de croissance adaptées au rythme du marché sénégalais
- Stratégie d'expansion régionale (dans le pays puis en Afrique de l'Ouest)

**10. Impact socio-économique**
- Contribution au développement économique du Sénégal
- Création d'emplois directs et indirects (estimations réalistes)
- Alignement avec les objectifs de développement nationaux
- Mesures de durabilité et responsabilité sociale

Intègre dans ton plan des références à des institutions, programmes, et cadres réglementaires sénégalais pertinents (APIX, ADEPME, Délégation à l'Entrepreneuriat Rapide, etc.). Mentionne des zones géographiques spécifiques et des acteurs locaux quand c'est pertinent. Inclus des termes et expressions en langues locales lorsque c'est approprié pour renforcer l'ancrage culturel.`;

  return prompt;
}

// Helper to create a prompt for market research
export function createMarketResearchPrompt(
  sector: string,
  product: string,
  region: string
) {
  const prompt = `Réalise une étude de marché approfondie, factuelle et détaillée pour un produit/service "${product}" dans le secteur "${sector}" au Sénégal en 2024, avec une attention particulière à la région de "${region}".

Tu dois produire une analyse qui:
- S'appuie sur des données économiques et démographiques précises et actuelles du Sénégal
- Prend en compte les spécificités culturelles, géographiques et économiques de la région de ${region}
- Analyse le comportement des consommateurs sénégalais dans ce secteur précis
- Identifie avec précision les acteurs existants sur ce marché au Sénégal
- Tient compte des conditions logistiques, infrastructurelles et réglementaires locales
- Propose des stratégies adaptées aux réalités du terrain sénégalais
- Est ancrée dans les réalités économiques et sociales du pays

Ta réponse doit être en français et structurée avec les sections suivantes (utilise des titres en gras):

**1. Aperçu du marché sénégalais pour ce secteur**
- Taille du marché en FCFA avec sources de données (si disponibles)
- État actuel et maturité du secteur ${sector} au Sénégal
- Cadre réglementaire et légal spécifique qui régit ce secteur au Sénégal
- Facteurs macroéconomiques influençant ce secteur (inflation, politique monétaire, etc.)
- Cartographie des principales zones d'activité pour ce secteur au Sénégal

**2. Analyse de la demande dans la région de ${region}**
- Caractéristiques démographiques et socio-économiques spécifiques à ${region}
- Estimation de la demande potentielle avec chiffres à l'appui
- Saisonnalité et cycles de consommation particuliers à la région
- Besoins non satisfaits ou mal servis dans cette région
- Pouvoir d'achat et habitudes de dépense locales

**3. Profil détaillé des clients potentiels**
- Segmentation précise du marché avec données démographiques sénégalaises
- Comportements d'achat spécifiques aux consommateurs sénégalais
- Motivations et freins à l'achat dans le contexte culturel local
- Processus de décision d'achat adapté aux réalités locales
- Analyse des besoins exprimés et latents selon les catégories socioprofessionnelles

**4. Analyse de la concurrence locale et régionale**
- Identification précise des concurrents directs au Sénégal (avec noms réels quand possible)
- Forces et faiblesses des offres existantes sur le marché sénégalais
- Parts de marché des acteurs principaux (si disponibles)
- Stratégies marketing et commerciales utilisées par la concurrence locale
- Barrières à l'entrée spécifiques au marché sénégalais

**5. Prix et positionnement recommandés**
- Analyse des prix pratiqués sur le marché local (en FCFA)
- Stratégie de prix adaptée au pouvoir d'achat sénégalais
- Positionnement recommandé vis-à-vis des offres existantes
- Proposition de valeur unique adaptée aux attentes des consommateurs sénégalais
- Stratégies promotionnelles efficaces dans le contexte local

**6. Canaux de distribution et commercialisation**
- Cartographie des circuits de distribution existants au Sénégal
- Recommandations de canaux adaptés aux spécificités de ${region}
- Analyse des modes d'approvisionnement et logistique dans la région
- Opportunités offertes par le commerce électronique et le mobile money au Sénégal
- Partenariats stratégiques potentiels avec des acteurs locaux

**7. Tendances et évolutions du marché**
- Innovations récentes dans ce secteur au Sénégal
- Évolutions des comportements des consommateurs sénégalais
- Impact des nouvelles technologies sur ce marché au Sénégal
- Influence des tendances régionales et internationales sur le marché local
- Projections d'évolution à moyen terme (3-5 ans)

**8. Analyse des risques spécifiques**
- Risques particuliers liés au contexte sénégalais (politiques, économiques, etc.)
- Défis culturels et sociaux à considérer dans cette région
- Obstacles logistiques et infrastructurels propres à ${region}
- Facteurs climatiques ou saisonniers impactant l'activité
- Stratégies d'atténuation des risques adaptées au contexte local

**9. Recommandations stratégiques**
- Stratégies d'entrée sur le marché sénégalais adaptées à ce secteur
- Adaptations du produit/service aux besoins spécifiques des consommateurs locaux
- Actions marketing prioritaires pour pénétrer efficacement le marché
- Partenariats locaux recommandés pour faciliter l'accès au marché
- Indicateurs clés de performance à suivre dans le contexte sénégalais

**10. Conclusion et opportunités de marché**
- Synthèse du potentiel global pour ce produit/service au Sénégal
- Projection de croissance réaliste sur le marché de ${region}
- Conditions critiques de succès dans le contexte sénégalais
- Timing optimal pour l'entrée sur le marché
- Facteurs différenciants pour réussir spécifiquement au Sénégal

Intègre dans ton analyse des informations sur des événements commerciaux pertinents au Sénégal (foires, salons), des références à des institutions locales (CCI, chambres de commerce régionales), et utilise des termes ou expressions en langues locales quand c'est pertinent. Mentionne des lieux, quartiers et zones commerciales spécifiques de la région concernée, ainsi que des acteurs locaux quand c'est approprié.`;

  return prompt;
}