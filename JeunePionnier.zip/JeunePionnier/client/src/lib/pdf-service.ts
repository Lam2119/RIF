import { jsPDF } from 'jspdf';
import { marked } from 'marked';
import * as htmlToText from 'html-to-text';

export function simpleMarkdownToHtml(markdown: string): string {
  return marked(markdown);
}

export function cleanMarkdown(markdown: string): string {
  const html = marked(markdown);
  return htmlToText.convert(html, {
    wordwrap: 130,
    selectors: [
      { selector: 'a', options: { hideLinkHrefIfSameAsText: true } },
      { selector: 'img', format: 'skip' }
    ]
  });
}

export function generatePdfFromMarkdown(markdown: string, filename: string = 'document.pdf'): void {
  try {
    const doc = new jsPDF();

    // Configuration
    const pageWidth = doc.internal.pageSize.width;
    const pageHeight = doc.internal.pageSize.height;
    const margin = 20;
    const textWidth = pageWidth - (2 * margin);

    // En-tête avec logo Ndimbal
    doc.setFillColor(0, 133, 63); // Vert Ndimbal
    doc.rect(0, 0, pageWidth, 25, 'F');

    // Titre du document
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('Ndimbal - Assistant Entrepreneurial', margin, 17);

    // Date de génération
    const date = new Date().toLocaleDateString('fr-FR');
    doc.setFontSize(10);
    doc.text(`Généré le ${date}`, pageWidth - margin - 40, 17);

    // Contenu principal
    const text = cleanMarkdown(markdown);
    const lines = text.split('\n');
    let y = 40;

    doc.setFont('helvetica', 'normal');
    lines.forEach(line => {
      if (line.trim() === '') {
        y += 5;
        return;
      }

      // Titres
      if (line.startsWith('#')) {
        const level = (line.match(/^#+/) || [''])[0].length;
        const title = line.replace(/^#+\s/, '');

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(0, 133, 63); // Vert Ndimbal
        switch(level) {
          case 1:
            doc.setFontSize(18);
            break;
          case 2:
            doc.setFontSize(16);
            doc.setTextColor(51, 51, 51);
            break;
          default:
            doc.setFontSize(14);
            doc.setTextColor(102, 102, 102);
        }

        const splitTitle = doc.splitTextToSize(title, textWidth);
        doc.text(splitTitle, margin, y);
        y += 10 * splitTitle.length;
      } else {
        // Texte normal
        doc.setFontSize(11);
        doc.setTextColor(51, 51, 51);
        doc.setFont('helvetica', 'normal');

        const splitText = doc.splitTextToSize(line, textWidth);
        doc.text(splitText, margin, y);
        y += 7 * splitText.length;
      }

      // Nouvelle page si nécessaire
      if (y > pageHeight - margin) {
        doc.addPage();
        // En-tête sur la nouvelle page
        doc.setFillColor(0, 133, 63);
        doc.rect(0, 0, pageWidth, 25, 'F');
        y = 40;
      }
    });

    // Pied de page sur chaque page
    const pageCount = doc.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFillColor(245, 245, 245);
      doc.rect(0, pageHeight - 20, pageWidth, 20, 'F');

      doc.setFontSize(10);
      doc.setTextColor(128, 128, 128);
      doc.setFont('helvetica', 'normal');
      doc.text(`Page ${i} sur ${pageCount}`, pageWidth - margin - 25, pageHeight - 10);
      doc.text('© Ndimbal', margin, pageHeight - 10);
    }

    doc.save(filename);
  } catch (error) {
    console.error('Erreur lors de la génération du PDF:', error);
    throw error;
  }
}

export function generateProjectPdf(project: any): void {
  const typeLabels: Record<string, string> = {
    'idea': 'Idée d\'entreprise',
    'business_plan': 'Plan d\'affaires',
    'market_research': 'Étude de marché',
    'feasibility_study': 'Étude de faisabilité',
    'financial_analysis': 'Analyse financière'
  };

  const typeLabel = typeLabels[project.type] || 'Document';
  const filePrefix = project.type.replace(/_/g, '-');
  const sanitizedSector = project.sector?.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'general';
  const filename = `${filePrefix}_${sanitizedSector}_${Date.now()}.pdf`;

  generatePdfFromMarkdown(project.content, filename);
}