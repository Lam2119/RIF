import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import IdeaGenerator from "@/pages/idea-generator";
import BusinessPlan from "@/pages/business-plan";
import MarketResearch from "@/pages/market-research";
import FeasibilityStudy from "@/pages/feasibility-study";
import FinancialAnalysis from "@/pages/financial-analysis";
import Resources from "@/pages/resources";
import SavedIdeas from "@/pages/saved-ideas";
import Favorites from "@/pages/favorites";
import AdminDashboard from "@/pages/admin-dashboard";

function Router() {
  return (
    <Switch>
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/idea-generator" component={IdeaGenerator} />
      <ProtectedRoute path="/business-plan" component={BusinessPlan} />
      <ProtectedRoute path="/market-research" component={MarketResearch} />
      <ProtectedRoute path="/feasibility-study" component={FeasibilityStudy} />
      <ProtectedRoute path="/financial-analysis" component={FinancialAnalysis} />
      <ProtectedRoute path="/resources" component={Resources} />
      <ProtectedRoute path="/saved-ideas" component={SavedIdeas} />
      <ProtectedRoute path="/favorites" component={Favorites} />
      <ProtectedRoute path="/admin" component={AdminDashboard} roles={["admin", "super_admin"]} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
