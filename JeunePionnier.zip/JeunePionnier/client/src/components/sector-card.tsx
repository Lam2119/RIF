import React from 'react';
import { SectorIcon } from '@/components/ui/svg-icons';

interface SectorCardProps {
  name: string;
  growth: string;
  image: string;
  onClick?: (sector: string) => void;
}

export function SectorCard({ name, growth, image, onClick }: SectorCardProps) {
  return (
    <div 
      className="bg-white rounded-xl shadow-sm overflow-hidden hover:transform hover:scale-103 transition-transform duration-300 relative cursor-pointer"
      onClick={() => onClick && onClick(name)}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
      
      {/* We'll use a background color instead of an image since we can't use real images */}
      <div 
        className="w-full h-48 bg-gradient-to-br"
        style={{ 
          backgroundColor: getSectorColor(name),
          backgroundSize: 'cover',
        }}
      >
        <div className="absolute top-3 left-3">
          <SectorIcon sector={name} className="w-10 h-10 text-white" />
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 p-4 text-white">
        <h3 className="font-montserrat font-bold text-lg">{name}</h3>
        <p className="text-sm opacity-90">{growth} de croissance</p>
      </div>
    </div>
  );
}

// Helper to get color based on sector
function getSectorColor(sector: string): string {
  switch (sector.toLowerCase()) {
    case 'agriculture':
      return '#2E7D32'; // Dark green
    case 'technologie':
      return '#1565C0'; // Dark blue
    case 'commerce':
      return '#5E35B1'; // Deep purple
    case 'artisanat':
      return '#EF6C00'; // Dark orange
    case 'education':
      return '#6A1B9A'; // Dark purple
    case 'sante':
      return '#C62828'; // Dark red
    case 'tourisme':
      return '#00695C'; // Dark teal
    case 'énergie renouvelable':
      return '#2E7D32'; // Dark green
    default:
      return '#455A64'; // Blue gray
  }
}
