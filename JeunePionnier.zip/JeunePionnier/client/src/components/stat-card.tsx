import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconColor: string;
  iconBgColor: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
}

export function StatCard({ title, value, icon, iconColor, iconBgColor, trend }: StatCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-5 hover:transform hover:scale-103 transition-transform duration-300">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-500 font-medium">{title}</p>
          <h3 className="text-2xl font-bold mt-2">{value}</h3>
        </div>
        <div className={`h-10 w-10 rounded-lg ${iconBgColor} flex items-center justify-center ${iconColor}`}>
          <i className={`${icon} text-xl`}></i>
        </div>
      </div>
      
      {trend && (
        <div className={`flex items-center mt-4 text-xs ${trend.isPositive ? 'text-[#00853F]' : 'text-[#D21034]'}`}>
          <i className={`${trend.isPositive ? 'ri-arrow-up-line' : 'ri-arrow-down-line'} mr-1`}></i>
          <span>{trend.value}</span>
        </div>
      )}
    </div>
  );
}
