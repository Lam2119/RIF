import React, { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { SenegalPattern } from '@/components/ui/svg-icons';
import { ideaGeneratorSchema, type IdeaGeneratorInput } from '@shared/schema';
import { createBusinessIdeaPrompt, generateWithAI } from '@/lib/openrouter-api';
import { Loader2 } from 'lucide-react';

interface IdeaGeneratorFormProps {
  onResult?: (result: string, originalMarkdown?: string) => void;
}

export function IdeaGeneratorForm({ onResult }: IdeaGeneratorFormProps) {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);

  const form = useForm<IdeaGeneratorInput>({
    resolver: zodResolver(ideaGeneratorSchema),
    defaultValues: {
      sector: '',
      budget: '',
      vision: '',
    },
  });

  const onSubmit = async (data: IdeaGeneratorInput) => {
    try {
      setIsGenerating(true);
      
      // Create the prompt for the AI
      const prompt = createBusinessIdeaPrompt(
        data.sector,
        data.budget,
        data.vision
      );
      
      // Call the AI API
      const result = await generateWithAI(prompt);
      
      // Call onResult with the generated idea and original markdown
      if (onResult) {
        onResult(result.content, result.originalMarkdown);
      }
      
      toast({
        title: 'Idée générée avec succès',
        description: 'Votre idée d\'entreprise a été générée avec succès.',
      });
    } catch (error) {
      console.error('Error generating idea:', error);
      toast({
        title: 'Erreur lors de la génération',
        description: 'Une erreur est survenue lors de la génération de l\'idée.',
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <div className="senegal-pattern h-3"></div>
      <CardContent className="p-6">
        <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
          <i className="ri-brain-line text-[#00853F] mr-2"></i>
          Générer une idée d'entreprise
        </h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="sector"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Secteur d'activité</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez un secteur" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="agriculture">Agriculture</SelectItem>
                      <SelectItem value="technologie">Technologie</SelectItem>
                      <SelectItem value="commerce">Commerce</SelectItem>
                      <SelectItem value="artisanat">Artisanat</SelectItem>
                      <SelectItem value="education">Éducation</SelectItem>
                      <SelectItem value="sante">Santé</SelectItem>
                      <SelectItem value="tourisme">Tourisme</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="budget"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Budget initial (FCFA)</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez un budget" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="moins de 200 000 FCFA">Moins de 200 000 FCFA</SelectItem>
                      <SelectItem value="entre 200 000 et 1 000 000 FCFA">200 000 - 1 000 000 FCFA</SelectItem>
                      <SelectItem value="entre 1 000 000 et 5 000 000 FCFA">1 000 000 - 5 000 000 FCFA</SelectItem>
                      <SelectItem value="plus de 5 000 000 FCFA">Plus de 5 000 000 FCFA</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="vision"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description de votre vision (facultatif)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Décrivez votre idée ou les besoins que vous souhaitez adresser..."
                      className="resize-none"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end">
              <Button 
                type="submit"
                className="bg-[#00853F] hover:bg-[#00853F]/90"
                disabled={isGenerating}
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Génération en cours...
                  </>
                ) : (
                  <>
                    <i className="ri-magic-line mr-2"></i>
                    Générer avec IA
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
