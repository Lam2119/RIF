import React, { useState } from 'react';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';

// Define schema for market research form
const marketResearchSchema = z.object({
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  product: z.string().min(3, "Le nom du produit doit contenir au moins 3 caractères"),
  region: z.string().min(1, "Veuillez sélectionner une région"),
});

// Schema for saving a generated market research
const saveResearchSchema = z.object({
  title: z.string().min(3, "Le titre doit contenir au moins 3 caractères"),
  description: z.string().min(10, "La description doit contenir au moins 10 caractères"),
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  region: z.string().min(1, "Veuillez sélectionner une région"),
});

type MarketResearchFormData = z.infer<typeof marketResearchSchema>;
type SaveResearchFormData = z.infer<typeof saveResearchSchema>;

interface MarketResearchFormProps {
  onSubmit: (data: MarketResearchFormData) => void;
  isLoading: boolean;
  researchResult: string | null;
  onSave: (title: string, description: string, sector: string, region: string) => void;
}

export function MarketResearchForm({ onSubmit, isLoading, researchResult, onSave }: MarketResearchFormProps) {
  const [activeTab, setActiveTab] = useState<string>("create");
  
  // Market research generation form
  const form = useForm<MarketResearchFormData>({
    resolver: zodResolver(marketResearchSchema),
    defaultValues: {
      sector: '',
      product: '',
      region: '',
    },
  });

  // Save market research form
  const saveForm = useForm<SaveResearchFormData>({
    resolver: zodResolver(saveResearchSchema),
    defaultValues: {
      title: '',
      description: '',
      sector: '',
      region: '',
    },
  });

  const handleFormSubmit = (data: MarketResearchFormData) => {
    onSubmit(data);
    
    // Pre-fill the save form with some data
    saveForm.setValue('title', `Étude de marché: ${data.product}`);
    saveForm.setValue('description', `Étude de marché pour ${data.product} dans le secteur ${data.sector} à ${data.region}.`);
    saveForm.setValue('sector', data.sector);
    saveForm.setValue('region', data.region);
  };

  const handleSaveSubmit = (data: SaveResearchFormData) => {
    onSave(data.title, data.description, data.sector, data.region);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <div className="h-3 bg-[#D21034]"></div>
      <CardContent className="p-6">
        {researchResult ? (
          <Tabs defaultValue="create" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="create">Générer</TabsTrigger>
              <TabsTrigger value="save">Sauvegarder</TabsTrigger>
            </TabsList>
            
            <TabsContent value="create">
              <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                <i className="ri-pie-chart-line text-[#D21034] mr-2"></i>
                Créer une étude de marché
              </h2>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="sector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secteur d'activité</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un secteur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="agriculture">Agriculture</SelectItem>
                            <SelectItem value="technologie">Technologie</SelectItem>
                            <SelectItem value="commerce">Commerce</SelectItem>
                            <SelectItem value="artisanat">Artisanat</SelectItem>
                            <SelectItem value="education">Éducation</SelectItem>
                            <SelectItem value="sante">Santé</SelectItem>
                            <SelectItem value="tourisme">Tourisme</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="product"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Produit ou service</FormLabel>
                        <FormControl>
                          <Input placeholder="Nom du produit ou service" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Région cible</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez une région" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="dakar">Dakar</SelectItem>
                            <SelectItem value="thies">Thiès</SelectItem>
                            <SelectItem value="saint-louis">Saint-Louis</SelectItem>
                            <SelectItem value="diourbel">Diourbel</SelectItem>
                            <SelectItem value="louga">Louga</SelectItem>
                            <SelectItem value="fatick">Fatick</SelectItem>
                            <SelectItem value="kaolack">Kaolack</SelectItem>
                            <SelectItem value="kaffrine">Kaffrine</SelectItem>
                            <SelectItem value="tambacounda">Tambacounda</SelectItem>
                            <SelectItem value="kedougou">Kédougou</SelectItem>
                            <SelectItem value="kolda">Kolda</SelectItem>
                            <SelectItem value="sedhiou">Sédhiou</SelectItem>
                            <SelectItem value="ziguinchor">Ziguinchor</SelectItem>
                            <SelectItem value="matam">Matam</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveTab("save")}
                    >
                      Sauvegarder le résultat
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-[#D21034] hover:bg-[#D21034]/90"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Génération en cours...
                        </>
                      ) : (
                        <>
                          <i className="ri-pie-chart-line mr-2"></i>
                          Générer une nouvelle étude
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="save">
              <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                <i className="ri-save-line text-[#00853F] mr-2"></i>
                Sauvegarder l'étude de marché
              </h2>
              
              <Form {...saveForm}>
                <form onSubmit={saveForm.handleSubmit(handleSaveSubmit)} className="space-y-4">
                  <FormField
                    control={saveForm.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Titre de l'étude</FormLabel>
                        <FormControl>
                          <Input placeholder="Titre de l'étude de marché" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description brève</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Brève description de l'étude de marché"
                            className="resize-none"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="sector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secteur d'activité</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un secteur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="agriculture">Agriculture</SelectItem>
                            <SelectItem value="technologie">Technologie</SelectItem>
                            <SelectItem value="commerce">Commerce</SelectItem>
                            <SelectItem value="artisanat">Artisanat</SelectItem>
                            <SelectItem value="education">Éducation</SelectItem>
                            <SelectItem value="sante">Santé</SelectItem>
                            <SelectItem value="tourisme">Tourisme</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Région cible</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez une région" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="dakar">Dakar</SelectItem>
                            <SelectItem value="thies">Thiès</SelectItem>
                            <SelectItem value="saint-louis">Saint-Louis</SelectItem>
                            <SelectItem value="diourbel">Diourbel</SelectItem>
                            <SelectItem value="louga">Louga</SelectItem>
                            <SelectItem value="fatick">Fatick</SelectItem>
                            <SelectItem value="kaolack">Kaolack</SelectItem>
                            <SelectItem value="kaffrine">Kaffrine</SelectItem>
                            <SelectItem value="tambacounda">Tambacounda</SelectItem>
                            <SelectItem value="kedougou">Kédougou</SelectItem>
                            <SelectItem value="kolda">Kolda</SelectItem>
                            <SelectItem value="sedhiou">Sédhiou</SelectItem>
                            <SelectItem value="ziguinchor">Ziguinchor</SelectItem>
                            <SelectItem value="matam">Matam</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveTab("create")}
                    >
                      Retour
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-[#00853F] hover:bg-[#00853F]/90"
                    >
                      <i className="ri-save-line mr-2"></i>
                      Sauvegarder
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        ) : (
          <>
            <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
              <i className="ri-pie-chart-line text-[#D21034] mr-2"></i>
              Créer une étude de marché
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="sector"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Secteur d'activité</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez un secteur" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="agriculture">Agriculture</SelectItem>
                          <SelectItem value="technologie">Technologie</SelectItem>
                          <SelectItem value="commerce">Commerce</SelectItem>
                          <SelectItem value="artisanat">Artisanat</SelectItem>
                          <SelectItem value="education">Éducation</SelectItem>
                          <SelectItem value="sante">Santé</SelectItem>
                          <SelectItem value="tourisme">Tourisme</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="product"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Produit ou service</FormLabel>
                      <FormControl>
                        <Input placeholder="Nom du produit ou service" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="region"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Région cible</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez une région" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="dakar">Dakar</SelectItem>
                          <SelectItem value="thies">Thiès</SelectItem>
                          <SelectItem value="saint-louis">Saint-Louis</SelectItem>
                          <SelectItem value="diourbel">Diourbel</SelectItem>
                          <SelectItem value="louga">Louga</SelectItem>
                          <SelectItem value="fatick">Fatick</SelectItem>
                          <SelectItem value="kaolack">Kaolack</SelectItem>
                          <SelectItem value="kaffrine">Kaffrine</SelectItem>
                          <SelectItem value="tambacounda">Tambacounda</SelectItem>
                          <SelectItem value="kedougou">Kédougou</SelectItem>
                          <SelectItem value="kolda">Kolda</SelectItem>
                          <SelectItem value="sedhiou">Sédhiou</SelectItem>
                          <SelectItem value="ziguinchor">Ziguinchor</SelectItem>
                          <SelectItem value="matam">Matam</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end">
                  <Button 
                    type="submit"
                    className="bg-[#D21034] hover:bg-[#D21034]/90"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Génération en cours...
                      </>
                    ) : (
                      <>
                        <i className="ri-pie-chart-line mr-2"></i>
                        Générer l'étude
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </>
        )}
      </CardContent>
    </Card>
  );
}