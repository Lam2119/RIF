import React from 'react';
import { Project } from '@shared/schema';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';

interface ProjectCardProps {
  project: Project;
  onView?: (project: Project) => void;
  onEdit?: (project: Project) => void;
  onDownload?: (project: Project) => void;
}

// Helper to get color based on project type
const getColorByType = (type: string) => {
  switch (type) {
    case 'idea':
      return 'bg-[#00853F]';
    case 'business_plan':
      return 'bg-[#FFCC00]';
    case 'market_research':
      return 'bg-[#D21034]';
    default:
      return 'bg-purple-500';
  }
};

// Helper to get badge color based on sector
const getBadgeColorBySector = (sector: string) => {
  switch (sector.toLowerCase()) {
    case 'agriculture':
      return 'bg-green-100 text-green-800';
    case 'technologie':
      return 'bg-blue-100 text-blue-800';
    case 'commerce':
      return 'bg-indigo-100 text-indigo-800';
    case 'artisanat':
      return 'bg-yellow-100 text-yellow-800';
    case 'education':
      return 'bg-purple-100 text-purple-800';
    case 'sante':
      return 'bg-red-100 text-red-800';
    case 'tourisme':
      return 'bg-teal-100 text-teal-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export function ProjectCard({ project, onView, onEdit, onDownload }: ProjectCardProps) {
  const formatDate = (date: Date) => {
    return format(date, 'dd/MM/yyyy', { locale: fr });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden hover:transform hover:scale-103 transition-transform duration-300">
      <div className={`h-3 ${getColorByType(project.type)}`}></div>
      <div className="p-5">
        <div className="flex justify-between items-center mb-3">
          <Badge className={`${getBadgeColorBySector(project.sector)}`}>
            {project.sector}
          </Badge>
          <span className="text-xs text-gray-500">
            Créé le {formatDate(new Date(project.createdAt))}
          </span>
        </div>
        
        <h3 className="font-montserrat font-semibold text-lg mb-2">{project.title}</h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{project.description}</p>
        
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            {onView && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => onView(project)}
                className="h-8 w-8"
              >
                <i className="ri-eye-line text-gray-500"></i>
              </Button>
            )}
            
            {onEdit && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => onEdit(project)}
                className="h-8 w-8"
              >
                <i className="ri-edit-line text-gray-500"></i>
              </Button>
            )}
            
            {onDownload && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => onDownload(project)}
                className="h-8 w-8"
              >
                <i className="ri-download-line text-gray-500"></i>
              </Button>
            )}
          </div>
          
          <div className="flex items-center">
            <Progress value={project.progress} className="w-12 h-2" />
            <span className="ml-2 text-xs text-gray-500">{project.progress}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
