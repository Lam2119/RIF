import React, { useState } from 'react';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { 
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { SenegalPattern } from '@/components/ui/svg-icons';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';

// Define schema for business plan form
const businessPlanSchema = z.object({
  businessName: z.string().min(3, "Le nom de l'entreprise doit contenir au moins 3 caractères"),
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  description: z.string().min(20, "La description doit contenir au moins 20 caractères"),
});

// Schema for saving a generated business plan
const savePlanSchema = z.object({
  title: z.string().min(3, "Le titre doit contenir au moins 3 caractères"),
  description: z.string().min(10, "La description doit contenir au moins 10 caractères"),
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  budget: z.string().min(1, "Veuillez sélectionner un budget"),
});

type BusinessPlanFormData = z.infer<typeof businessPlanSchema>;
type SavePlanFormData = z.infer<typeof savePlanSchema>;

interface BusinessPlanFormProps {
  onSubmit: (data: BusinessPlanFormData) => void;
  isLoading: boolean;
  businessPlanResult: string | null;
  onSave: (title: string, description: string, sector: string, budget: string) => void;
}

export function BusinessPlanForm({ onSubmit, isLoading, businessPlanResult, onSave }: BusinessPlanFormProps) {
  const [activeTab, setActiveTab] = useState<string>("create");
  
  // Business plan generation form
  const form = useForm<BusinessPlanFormData>({
    resolver: zodResolver(businessPlanSchema),
    defaultValues: {
      businessName: '',
      sector: '',
      description: '',
    },
  });

  // Save business plan form
  const saveForm = useForm<SavePlanFormData>({
    resolver: zodResolver(savePlanSchema),
    defaultValues: {
      title: '',
      description: '',
      sector: '',
      budget: '',
    },
  });

  const handleFormSubmit = (data: BusinessPlanFormData) => {
    onSubmit(data);
    
    // Pre-fill the save form with some data
    saveForm.setValue('title', data.businessName);
    saveForm.setValue('description', data.description.slice(0, 200));
    saveForm.setValue('sector', data.sector);
  };

  const handleSaveSubmit = (data: SavePlanFormData) => {
    onSave(data.title, data.description, data.sector, data.budget);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <div className="h-3 bg-[#FFCC00]"></div>
      <CardContent className="p-6">
        {businessPlanResult ? (
          <Tabs defaultValue="create" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="create">Générer</TabsTrigger>
              <TabsTrigger value="save">Sauvegarder</TabsTrigger>
            </TabsList>
            
            <TabsContent value="create">
              <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                <i className="ri-file-chart-line text-[#FFCC00] mr-2"></i>
                Créer un business plan
              </h2>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="businessName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nom de l'entreprise</FormLabel>
                        <FormControl>
                          <Input placeholder="Nom de votre entreprise" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="sector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secteur d'activité</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un secteur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="agriculture">Agriculture</SelectItem>
                            <SelectItem value="technologie">Technologie</SelectItem>
                            <SelectItem value="commerce">Commerce</SelectItem>
                            <SelectItem value="artisanat">Artisanat</SelectItem>
                            <SelectItem value="education">Éducation</SelectItem>
                            <SelectItem value="sante">Santé</SelectItem>
                            <SelectItem value="tourisme">Tourisme</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description de l'entreprise</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Décrivez votre entreprise, ses produits ou services, sa mission..."
                            className="resize-none"
                            rows={5}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveTab("save")}
                    >
                      Sauvegarder le résultat
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-[#FFCC00] hover:bg-[#FFCC00]/90 text-black"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Génération en cours...
                        </>
                      ) : (
                        <>
                          <i className="ri-file-chart-line mr-2"></i>
                          Générer un nouveau plan
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="save">
              <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
                <i className="ri-save-line text-[#00853F] mr-2"></i>
                Sauvegarder le business plan
              </h2>
              
              <Form {...saveForm}>
                <form onSubmit={saveForm.handleSubmit(handleSaveSubmit)} className="space-y-4">
                  <FormField
                    control={saveForm.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Titre du business plan</FormLabel>
                        <FormControl>
                          <Input placeholder="Titre du business plan" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description brève</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Brève description du business plan"
                            className="resize-none"
                            rows={3}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="sector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secteur d'activité</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un secteur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="agriculture">Agriculture</SelectItem>
                            <SelectItem value="technologie">Technologie</SelectItem>
                            <SelectItem value="commerce">Commerce</SelectItem>
                            <SelectItem value="artisanat">Artisanat</SelectItem>
                            <SelectItem value="education">Éducation</SelectItem>
                            <SelectItem value="sante">Santé</SelectItem>
                            <SelectItem value="tourisme">Tourisme</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={saveForm.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Budget estimé</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un budget" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="moins de 200 000 FCFA">Moins de 200 000 FCFA</SelectItem>
                            <SelectItem value="entre 200 000 et 1 000 000 FCFA">200 000 - 1 000 000 FCFA</SelectItem>
                            <SelectItem value="entre 1 000 000 et 5 000 000 FCFA">1 000 000 - 5 000 000 FCFA</SelectItem>
                            <SelectItem value="plus de 5 000 000 FCFA">Plus de 5 000 000 FCFA</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setActiveTab("create")}
                    >
                      Retour
                    </Button>
                    <Button 
                      type="submit"
                      className="bg-[#00853F] hover:bg-[#00853F]/90"
                    >
                      <i className="ri-save-line mr-2"></i>
                      Sauvegarder
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        ) : (
          <>
            <h2 className="text-xl font-montserrat font-bold mb-4 flex items-center">
              <i className="ri-file-chart-line text-[#FFCC00] mr-2"></i>
              Créer un business plan
            </h2>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="businessName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nom de l'entreprise</FormLabel>
                      <FormControl>
                        <Input placeholder="Nom de votre entreprise" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="sector"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Secteur d'activité</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez un secteur" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="agriculture">Agriculture</SelectItem>
                          <SelectItem value="technologie">Technologie</SelectItem>
                          <SelectItem value="commerce">Commerce</SelectItem>
                          <SelectItem value="artisanat">Artisanat</SelectItem>
                          <SelectItem value="education">Éducation</SelectItem>
                          <SelectItem value="sante">Santé</SelectItem>
                          <SelectItem value="tourisme">Tourisme</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description de l'entreprise</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Décrivez votre entreprise, ses produits ou services, sa mission..."
                          className="resize-none"
                          rows={5}
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="flex justify-end">
                  <Button 
                    type="submit"
                    className="bg-[#FFCC00] hover:bg-[#FFCC00]/90 text-black"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Génération en cours...
                      </>
                    ) : (
                      <>
                        <i className="ri-file-chart-line mr-2"></i>
                        Générer un business plan
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </>
        )}
      </CardContent>
    </Card>
  );
}
