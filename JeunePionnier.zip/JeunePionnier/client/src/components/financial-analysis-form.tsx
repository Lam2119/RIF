import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { financialAnalysisSchema, FinancialAnalysisInput } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const saveAnalysisSchema = z.object({
  title: z.string().min(3, "Le titre doit contenir au moins 3 caractères"),
  description: z.string().min(10, "La description doit contenir au moins 10 caractères"),
  sector: z.string().min(1, "Veuillez sélectionner un secteur"),
  initialInvestment: z.string().min(1, "Veuillez indiquer l'investissement initial")
});

type SaveAnalysisFormData = z.infer<typeof saveAnalysisSchema>;

interface FinancialAnalysisFormProps {
  onSubmit: (data: FinancialAnalysisInput) => void;
  isLoading: boolean;
  analysisResult: string | null;
  onSave: (title: string, description: string, sector: string, initialInvestment: string) => void;
}

export function FinancialAnalysisForm({ onSubmit, isLoading, analysisResult, onSave }: FinancialAnalysisFormProps) {
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  
  const sectorOptions = [
    { value: "agriculture", label: "Agriculture & Agroalimentaire" },
    { value: "tech", label: "Technologies & Innovation" },
    { value: "commerce", label: "Commerce & Distribution" },
    { value: "education", label: "Éducation & Formation" },
    { value: "sante", label: "Santé & Bien-être" },
    { value: "tourisme", label: "Tourisme & Hôtellerie" },
    { value: "artisanat", label: "Artisanat & Production locale" },
    { value: "transport", label: "Transport & Logistique" },
    { value: "energie", label: "Énergie & Environnement" },
    { value: "services", label: "Services aux entreprises" },
    { value: "finance", label: "Finance & Assurance" },
    { value: "culture", label: "Culture & Divertissement" }
  ];
  
  const timeframeOptions = [
    { value: "1 an", label: "1 an" },
    { value: "2 ans", label: "2 ans" },
    { value: "3 ans", label: "3 ans" },
    { value: "5 ans", label: "5 ans" },
    { value: "10 ans", label: "10 ans" }
  ];
  
  const form = useForm<FinancialAnalysisInput>({
    resolver: zodResolver(financialAnalysisSchema),
    defaultValues: {
      sector: "",
      projectType: "",
      initialInvestment: "",
      projectedRevenue: "",
      operatingCosts: "",
      timeframe: "",
      additionalNotes: ""
    }
  });
  
  const saveForm = useForm<SaveAnalysisFormData>({
    resolver: zodResolver(saveAnalysisSchema),
    defaultValues: {
      title: "",
      description: "",
      sector: form.getValues().sector || "",
      initialInvestment: form.getValues().initialInvestment || ""
    }
  });
  
  const handleFormSubmit = (data: FinancialAnalysisInput) => {
    onSubmit(data);
  };
  
  const handleSaveSubmit = (data: SaveAnalysisFormData) => {
    onSave(data.title, data.description, data.sector, data.initialInvestment);
    setIsSaveDialogOpen(false);
  };
  
  return (
    <div className="w-full">
      {!analysisResult ? (
        <Card>
          <CardContent className="pt-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleFormSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="sector"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Secteur d'activité</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          disabled={isLoading}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un secteur" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {sectorOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Choisissez le secteur dans lequel s'inscrit votre projet
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="projectType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type de projet</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ex: Restaurant, Ferme agricole, Application mobile..." 
                            {...field} 
                            disabled={isLoading}
                          />
                        </FormControl>
                        <FormDescription>
                          Décrivez brièvement le type de projet que vous souhaitez réaliser
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="initialInvestment"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Investissement initial</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ex: 5,000,000 FCFA" 
                            {...field} 
                            disabled={isLoading}
                          />
                        </FormControl>
                        <FormDescription>
                          Montant que vous prévoyez d'investir au démarrage
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="projectedRevenue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Revenus projetés</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ex: 12,000,000 FCFA par an" 
                            {...field} 
                            disabled={isLoading}
                          />
                        </FormControl>
                        <FormDescription>
                          Estimation des revenus à pleine capacité
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="operatingCosts"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Coûts d'exploitation</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Ex: 7,000,000 FCFA par an" 
                            {...field} 
                            disabled={isLoading}
                          />
                        </FormControl>
                        <FormDescription>
                          Estimation des coûts d'exploitation annuels
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="timeframe"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Période d'analyse</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          disabled={isLoading}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez une période" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {timeframeOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Horizon temporel pour l'analyse financière
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Informations supplémentaires (optionnel)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Informations supplémentaires sur le projet ou les hypothèses financières..." 
                          {...field} 
                          rows={4}
                          disabled={isLoading}
                        />
                      </FormControl>
                      <FormDescription>
                        Ajoutez des informations qui pourraient être utiles pour l'analyse
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Génération en cours...
                    </>
                  ) : (
                    "Générer l'analyse financière"
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="prose max-w-none">
                <div dangerouslySetInnerHTML={{ __html: analysisResult }} />
              </div>
              
              <div className="flex flex-col sm:flex-row justify-between gap-4 mt-8">
                <Button onClick={() => onSubmit(form.getValues())} disabled={isLoading} variant="outline">
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Régénération en cours...
                    </>
                  ) : (
                    "Régénérer l'analyse"
                  )}
                </Button>
                
                <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
                  <DialogTrigger asChild>
                    <Button>Sauvegarder cette analyse</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Sauvegarder l'analyse financière</DialogTitle>
                      <DialogDescription>
                        Donnez un titre et une description à cette analyse pour la retrouver facilement.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <Form {...saveForm}>
                      <form onSubmit={saveForm.handleSubmit(handleSaveSubmit)} className="space-y-4">
                        <FormField
                          control={saveForm.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Titre</FormLabel>
                              <FormControl>
                                <Input placeholder="Titre de l'analyse" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={saveForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Brève description du projet et de ses objectifs financiers" 
                                  {...field} 
                                  rows={3}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={saveForm.control}
                          name="sector"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Secteur</FormLabel>
                              <Select
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                              >
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Sélectionnez un secteur" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {sectorOptions.map((option) => (
                                    <SelectItem key={option.value} value={option.value}>
                                      {option.label}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={saveForm.control}
                          name="initialInvestment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Investissement initial</FormLabel>
                              <FormControl>
                                <Input placeholder="Ex: 5,000,000 FCFA" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <DialogFooter>
                          <Button type="submit">Sauvegarder</Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}