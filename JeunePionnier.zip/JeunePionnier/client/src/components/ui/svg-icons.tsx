import React from 'react';

type IconProps = {
  className?: string;
};

export const LogoIcon: React.FC<IconProps> = ({ className = "" }) => (
  <svg 
    viewBox="0 0 32 32" 
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="32" height="32" rx="16" fill="#00853F" />
    <path d="M10.5 8L21.5 16L10.5 24V8Z" fill="white" />
  </svg>
);

export const SenegalStar: React.FC<IconProps> = ({ className = "" }) => (
  <svg 
    viewBox="0 0 24 24" 
    className={className}
    xmlns="http://www.w3.org/2000/svg"
  >
    <polygon 
      points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" 
      fill="#FFCC00" 
      stroke="#00853F" 
      strokeWidth="1" 
    />
  </svg>
);

export const SenegalPattern: React.FC<IconProps> = ({ className = "" }) => (
  <svg 
    className={className} 
    viewBox="0 0 100 10"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="100" height="10" fill="#00853F" fillOpacity="0.1" />
    <path 
      d="M0 0 L10 10 M20 0 L30 10 M40 0 L50 10 M60 0 L70 10 M80 0 L90 10" 
      stroke="#00853F" 
      strokeWidth="1" 
      strokeOpacity="0.2" 
    />
  </svg>
);

export const SectorIcon: React.FC<{ sector: string; className?: string }> = ({ sector, className = "" }) => {
  const iconPath = () => {
    switch (sector.toLowerCase()) {
      case 'agriculture':
        return (
          <path d="M5,16c0,3.87 3.13,7 7,7s7,-3.13 7,-7c0,-1.47 -0.5,-2.83 -1.25,-3.97L12,2L6.25,12.03C5.5,13.17 5,14.53 5,16zM14.5,16H13v-1.5h-2V16H9.5v-2h5V16z" fill="currentColor" />
        );
      case 'technologie':
        return (
          <path d="M18,13h-5v5h5V13zM16,2v2H8V2H6v2H5C3.89,4 3.01,4.9 3.01,6L3,20c0,1.1 0.89,2 2,2h14c1.1,0 2,-0.9 2,-2V6c0,-1.1 -0.9,-2 -2,-2h-1V2H16zM5,9h14v11H5V9z" fill="currentColor" />
        );
      case 'commerce':
        return (
          <path d="M7,18c-1.1,0 -1.99,0.9 -1.99,2S5.9,22 7,22s2,-0.9 2,-2 -0.9,-2 -2,-2zM1,3c0,0.55 0.45,1 1,1h1l3.6,7.59 -1.35,2.44C4.52,15.37 5.48,17 7,17h11c0.55,0 1,-0.45 1,-1s-0.45,-1 -1,-1L7,15l1.1,-2h7.45c0.75,0 1.41,-0.41 1.75,-1.03l3.58,-6.49c0.37,-0.66 -0.11,-1.48 -0.87,-1.48L5.21,4l-0.67,-1.43c-0.16,-0.35 -0.52,-0.57 -0.9,-0.57L2,2c-0.55,0 -1,0.45 -1,1zM17,18c-1.1,0 -1.99,0.9 -1.99,2s0.89,2 1.99,2 2,-0.9 2,-2 -0.9,-2 -2,-2z" fill="currentColor" />
        );
      case 'artisanat':
        return (
          <path d="M13.35,20.13c-0.76,0.69 -1.93,0.69 -2.69,-0.01l-0.11,-0.1C5.3,15.27 1.87,12.16 2,8.28c0.06,-1.7 0.93,-3.33 2.34,-4.29c2.64,-1.8 5.9,-0.96 7.66,1.1c1.76,-2.06 5.02,-2.91 7.66,-1.1c1.41,0.96 2.28,2.59 2.34,4.29c0.14,3.88 -3.3,6.99 -8.55,11.76l-0.1,0.09z" fill="currentColor" />
        );
      case 'education':
        return (
          <path d="M5,13.18v2.81c0,0.73 0.4,1.41 1.04,1.76l5,2.73c0.6,0.33 1.32,0.33 1.92,0l5,-2.73c0.64,-0.35 1.04,-1.03 1.04,-1.76v-2.81l-6.04,3.3c-0.6,0.33 -1.32,0.33 -1.92,0L5,13.18zM11.04,3.52l-8.43,4.6c-0.69,0.38 -0.69,1.38 0,1.76l8.43,4.6c0.6,0.33 1.32,0.33 1.92,0L21,10.09L21,16c0,0.55 0.45,1 1,1s1,-0.45 1,-1L23,9.59c0,-0.37 -0.2,-0.7 -0.52,-0.88l-9.52,-5.19c-0.6,-0.32 -1.32,-0.32 -1.92,0z" fill="currentColor" />
        );
      case 'sante':
        return (
          <path d="M19,3L5,3c-1.1,0 -1.99,0.9 -1.99,2L3,19c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2L21,5c0,-1.1 -0.9,-2 -2,-2zM11,8L9,8v2L7,10v2h2v2h2v-2h2v-2h-2L11,8zM17,14h-4v2h4v-2zM17,10h-4v2h4v-2z" fill="currentColor" />
        );
      case 'tourisme':
        return (
          <path d="M13.127,14.56l1.43,-1.43l6.44,6.443L19.57,21l-6.44,-6.44zM17.42,8.83l2.86,-2.86c-3.95,-3.95 -10.35,-3.96 -14.3,-0.02c3.93,-1.3 8.31,-0.25 11.44,2.88zM5.95,5.98c-3.94,3.95 -3.93,10.35 0.02,14.3l2.86,-2.86C5.7,14.29 4.65,9.91 5.95,5.98zM5.97,5.96l-0.01,0.01c-0.38,3.01 1.17,6.88 4.3,10.02l5.73,-5.73c-3.13,-3.13 -7.01,-4.68 -10.02,-4.3z" fill="currentColor" />
        );
      default:
        return (
          <path d="M9.29,6.71L9.29,6.71c-0.39,0.39 -0.39,1.02 0,1.41L13.17,12l-3.88,3.88c-0.39,0.39 -0.39,1.02 0,1.41l0,0c0.39,0.39 1.02,0.39 1.41,0l4.59,-4.59c0.39,-0.39 0.39,-1.02 0,-1.41l-4.59,-4.59C10.32,6.32 9.68,6.32 9.29,6.71z" fill="currentColor" />
        );
    }
  };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      className={className}
    >
      {iconPath()}
    </svg>
  );
};
