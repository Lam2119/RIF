import React from 'react';
import { Sidebar } from './sidebar';
import { MobileHeader } from './mobile-sidebar';
import { PageContainer } from './page-container';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden bg-neutral-50 font-lato text-neutral-dark">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <MobileHeader />
        
        <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
          <PageContainer>
            {children}
          </PageContainer>
        </main>
      </div>
    </div>
  );
}
