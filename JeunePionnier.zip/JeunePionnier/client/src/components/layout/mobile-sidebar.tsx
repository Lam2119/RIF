import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { LogoIcon } from '@/components/ui/svg-icons';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SidebarItem } from './sidebar';
import { Separator } from '@/components/ui/separator';

const mainMenu: SidebarItem[] = [
  { title: 'Tableau de bord', icon: 'ri-dashboard-line', href: '/' },
  { title: 'Générateur d\'idées', icon: 'ri-lightbulb-line', href: '/idea-generator' },
  { title: 'Business Plans', icon: 'ri-file-chart-line', href: '/business-plan' },
  { title: 'Études de marché', icon: 'ri-search-line', href: '/market-research' },
  { title: 'Ressources', icon: 'ri-compass-3-line', href: '/resources' },
];

const projectsMenu: SidebarItem[] = [
  { title: 'Mes idées sauvegardées', icon: 'ri-folder-line', href: '/saved-ideas' },
  { title: 'Favoris', icon: 'ri-bookmark-line', href: '/favorites' },
];

const adminMenu: SidebarItem[] = [
  { title: 'Administration', icon: 'ri-admin-line', href: '/admin', roles: ['admin', 'super_admin'] },
];

export function MobileHeader() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useAuth();
  const [_, navigate] = useLocation();

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Close the sidebar when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.getElementById('mobile-sidebar');
      const menuButton = document.getElementById('mobile-menu-button');
      
      if (sidebar && 
          !sidebar.contains(event.target as Node) && 
          menuButton && 
          !menuButton.contains(event.target as Node) && 
          isSidebarOpen) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isSidebarOpen]);

  return (
    <>
      <div className="md:hidden fixed top-0 left-0 right-0 bg-white z-30 border-b">
        <div className="flex items-center justify-between px-4 py-3">
          <button 
            id="mobile-menu-button" 
            className="p-2 rounded-md text-gray-500 hover:text-gray-600 focus:outline-none"
            onClick={toggleSidebar}
          >
            <i className="ri-menu-line text-2xl"></i>
          </button>
          <div className="flex items-center space-x-2">
            <LogoIcon className="h-7 w-7" />
            <h1 className="text-xl font-montserrat font-bold text-[#00853F]">Ndimbal</h1>
          </div>
          <button 
            className="p-2 rounded-md text-gray-500 hover:text-gray-600 focus:outline-none"
            onClick={() => navigate('/profile')}
          >
            <Avatar className="h-8 w-8">
              <AvatarImage src="" />
              <AvatarFallback className="bg-[#00853F] text-white text-xs">
                {user?.fullName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'ND'}
              </AvatarFallback>
            </Avatar>
          </button>
        </div>
      </div>

      {/* Mobile Sidebar */}
      <MobileSidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />
      
      {/* Mobile FAB */}
      <div className="fixed right-6 bottom-6 md:hidden">
        <button 
          className="h-14 w-14 rounded-full bg-[#00853F] text-white shadow-lg flex items-center justify-center"
          onClick={() => navigate('/idea-generator')}
        >
          <i className="ri-add-line text-2xl"></i>
        </button>
      </div>
    </>
  );
}

function MobileSidebar({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [location] = useLocation();
  const { user, logoutMutation, isAdmin } = useAuth();

  // Helper to check if current path matches the link
  const isActive = (path: string) => location === path;

  // Helper to render sidebar item
  const renderSidebarItem = (item: SidebarItem) => {
    // Skip if item has roles and user doesn't have those roles
    if (item.roles && (!user || !item.roles.includes(user.role))) {
      return null;
    }

    return (
      <Link 
        key={item.href}
        href={item.href}
        className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
          isActive(item.href) 
            ? 'bg-[#00853F] bg-opacity-10 text-[#00853F]' 
            : 'text-gray-700 hover:bg-[#00853F] hover:bg-opacity-10 hover:text-[#00853F]'
        }`}
        onClick={onClose}
      >
        <i className={`${item.icon} mr-3 text-lg`}></i>
        <span>{item.title}</span>
      </Link>
    );
  };

  return (
    <div id="mobile-sidebar" className={`fixed inset-0 bg-black/70 z-40 md:hidden transition-opacity duration-200 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
      <div className={`fixed inset-y-0 left-0 max-w-xs w-full bg-white shadow-xl flex flex-col transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-2">
            <LogoIcon className="h-8 w-8" />
            <h1 className="text-2xl font-montserrat font-bold text-[#00853F]">Ndimbal</h1>
          </div>
          <button 
            id="close-sidebar" 
            className="p-2 rounded-md text-gray-500 hover:text-gray-600 focus:outline-none"
            onClick={onClose}
          >
            <i className="ri-close-line text-2xl"></i>
          </button>
        </div>
        
        <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
          <div className="px-3 py-2">
            <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Menu Principal</h2>
          </div>
          
          {mainMenu.map(renderSidebarItem)}
          
          <div className="px-3 py-2 mt-6">
            <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Mes Projets</h2>
          </div>
          
          {projectsMenu.map(renderSidebarItem)}

          {isAdmin && (
            <>
              <div className="px-3 py-2 mt-6">
                <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Administration</h2>
              </div>
              
              {adminMenu.map(renderSidebarItem)}
            </>
          )}

          <Separator className="my-4" />
          
          <button
            onClick={() => {
              logoutMutation.mutate();
              onClose();
            }}
            className="w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg text-gray-700 hover:bg-red-100 hover:text-red-600 transition-colors"
          >
            <i className="ri-logout-box-line mr-3 text-lg"></i>
            <span>Déconnexion</span>
          </button>
        </nav>
        
        <div className="p-4 border-t">
          <div className="flex items-center">
            <Avatar>
              <AvatarImage src="" />
              <AvatarFallback className="bg-[#00853F] text-white">
                {user?.fullName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'ND'}
              </AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.fullName || 'Utilisateur'}</p>
              <p className="text-xs text-gray-500">{user?.email || ''}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
