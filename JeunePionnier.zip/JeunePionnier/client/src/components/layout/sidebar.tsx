import React from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { LogoIcon } from '@/components/ui/svg-icons';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

export interface SidebarItem {
  title: string;
  icon: string;
  href: string;
  roles?: string[];
}

const mainMenu: SidebarItem[] = [
  { title: 'Tableau de bord', icon: 'ri-dashboard-line', href: '/' },
  { title: 'Générateur d\'idées', icon: 'ri-lightbulb-line', href: '/idea-generator' },
  { title: 'Business Plans', icon: 'ri-file-chart-line', href: '/business-plan' },
  { title: 'Études de marché', icon: 'ri-search-line', href: '/market-research' },
  { title: 'Études de faisabilité', icon: 'ri-file-search-line', href: '/feasibility-study' },
  { title: 'Analyses financières', icon: 'ri-funds-line', href: '/financial-analysis' },
  { title: 'Ressources', icon: 'ri-compass-3-line', href: '/resources' },
];

const projectsMenu: SidebarItem[] = [
  { title: 'Mes idées sauvegardées', icon: 'ri-folder-line', href: '/saved-ideas' },
  { title: 'Favoris', icon: 'ri-bookmark-line', href: '/favorites' },
];

const adminMenu: SidebarItem[] = [
  { title: 'Administration', icon: 'ri-admin-line', href: '/admin', roles: ['admin', 'super_admin'] },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation, isAdmin } = useAuth();

  // Helper to check if current path matches the link
  const isActive = (path: string) => location === path;

  // Helper to render sidebar item
  const renderSidebarItem = (item: SidebarItem) => {
    // Skip if item has roles and user doesn't have those roles
    if (item.roles && (!user || !item.roles.includes(user.role))) {
      return null;
    }

    return (
      <Link 
        key={item.href}
        href={item.href}
        className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${
          isActive(item.href) 
            ? 'bg-[#00853F] bg-opacity-10 text-[#00853F]' 
            : 'text-gray-700 hover:bg-[#00853F] hover:bg-opacity-10 hover:text-[#00853F]'
        }`}
      >
        <i className={`${item.icon} mr-3 text-lg`}></i>
        <span>{item.title}</span>
      </Link>
    );
  };

  return (
    <aside className="hidden md:flex md:flex-col bg-white shadow-lg z-20 w-64 flex-shrink-0 h-full">
      <div className="flex items-center justify-center py-6 border-b">
        <div className="flex items-center space-x-2">
          <LogoIcon className="h-8 w-8" />
          <h1 className="text-2xl font-montserrat font-bold text-[#00853F]">Ndimbal</h1>
        </div>
      </div>
      
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        <div className="px-3 py-2">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Menu Principal</h2>
        </div>
        
        {mainMenu.map(renderSidebarItem)}
        
        <div className="px-3 py-2 mt-6">
          <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Mes Projets</h2>
        </div>
        
        {projectsMenu.map(renderSidebarItem)}

        {isAdmin && (
          <>
            <div className="px-3 py-2 mt-6">
              <h2 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Administration</h2>
            </div>
            
            {adminMenu.map(renderSidebarItem)}
          </>
        )}

        <Separator className="my-4" />
        
        <button
          onClick={() => logoutMutation.mutate()}
          className="w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg text-gray-700 hover:bg-red-100 hover:text-red-600 transition-colors"
        >
          <i className="ri-logout-box-line mr-3 text-lg"></i>
          <span>Déconnexion</span>
        </button>
      </nav>
      
      <div className="p-4 border-t">
        <div className="flex items-center">
          <Avatar>
            <AvatarImage src="" />
            <AvatarFallback className="bg-[#00853F] text-white">
              {user?.fullName?.split(' ').map(n => n[0]).join('').toUpperCase() || 'ND'}
            </AvatarFallback>
          </Avatar>
          <div className="ml-3">
            <p className="text-sm font-medium">{user?.fullName || 'Utilisateur'}</p>
            <p className="text-xs text-gray-500">{user?.email || ''}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
