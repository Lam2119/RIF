
import React from 'react';
import { Resource } from '@shared/schema';
import { cn } from '@/lib/utils';
import { Card } from './ui/card';

interface ResourceCardProps {
  resource: Resource;
  onClick?: (resource: Resource) => void;
}

const getIconByType = (type: string) => {
  switch (type) {
    case 'document':
      return 'ri-file-text-line';
    case 'guide':
      return 'ri-book-open-line';
    case 'video':
      return 'ri-video-line';
    case 'link':
      return 'ri-link';
    default:
      return 'ri-file-line';
  }
};

const getColorByType = (type: string) => {
  switch (type) {
    case 'document':
      return {
        bg: 'bg-[#00853F] bg-opacity-10',
        text: 'text-[#00853F]',
        border: 'border-[#00853F]'
      };
    case 'guide':
      return {
        bg: 'bg-[#FFCC00] bg-opacity-10',
        text: 'text-[#FFCC00]',
        border: 'border-[#FFCC00]'
      };
    case 'video':
      return {
        bg: 'bg-[#D21034] bg-opacity-10',
        text: 'text-[#D21034]',
        border: 'border-[#D21034]'
      };
    case 'link':
      return {
        bg: 'bg-purple-500 bg-opacity-10',
        text: 'text-purple-500',
        border: 'border-purple-500'
      };
    default:
      return {
        bg: 'bg-gray-500 bg-opacity-10',
        text: 'text-gray-500',
        border: 'border-gray-500'
      };
  }
};

export function ResourceCard({ resource, onClick }: ResourceCardProps) {
  const { bg, text, border } = getColorByType(resource.type);
  const icon = getIconByType(resource.type);
  
  return (
    <Card 
      className={cn(
        "group relative overflow-hidden transition-all duration-300 hover:shadow-lg",
        onClick && "cursor-pointer"
      )}
      onClick={() => onClick && onClick(resource)}
    >
      <div className={`absolute top-0 left-0 w-1 h-full ${border.replace('border', 'bg')}`} />
      <div className="flex items-start p-4 pl-6">
        <div className={`h-12 w-12 rounded-lg ${bg} flex items-center justify-center ${text} mr-4 flex-shrink-0 transition-transform group-hover:scale-110`}>
          <i className={`${icon} text-2xl`}></i>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-1">
            <h3 className={`font-semibold truncate ${text}`}>
              {resource.title}
            </h3>
            <span className="text-xs font-medium px-2 py-1 rounded-full bg-gray-100 text-gray-600 ml-2">
              {resource.sector || 'Général'}
            </span>
          </div>
          <p className="text-sm text-gray-600 line-clamp-2">
            {resource.description}
          </p>
          {resource.url && (
            <div className="mt-2 flex items-center text-sm text-gray-500">
              <i className="ri-external-link-line mr-1"></i>
              <span className="truncate">
                {resource.url.replace(/^https?:\/\//, '')}
              </span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
